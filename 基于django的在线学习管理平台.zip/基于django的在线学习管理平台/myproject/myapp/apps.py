from django.apps import AppConfig


class MyappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'myapp'

    def ready(self):
        """自动确保存在一个通用超级管理员 admin1/1 （开发演示用）"""
        from django.contrib.auth import get_user_model
        from django.db.utils import OperationalError, ProgrammingError
        User = get_user_model()
        try:
            if not User.objects.filter(username='admin1').exists():
                User.objects.create_superuser(username='admin1', password='1', email='admin@example.com')
        except (OperationalError, ProgrammingError):
            # 数据库尚未迁移或表不存在时跳过
            pass
