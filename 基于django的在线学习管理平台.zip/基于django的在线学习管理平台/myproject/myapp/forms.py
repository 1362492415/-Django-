from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm, PasswordChangeForm
from django.contrib.auth.models import User
from django.contrib.auth import password_validation
from django.core.exceptions import ValidationError
from .models import UserProfile, Assignment, AssignmentSubmission, AssignmentGrade

class ChineseUserCreationForm(UserCreationForm):
    """自定义用户注册表单，使用中文提示信息"""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # 设置字段标签为中文
        self.fields['username'].label = '用户名'
        self.fields['password1'].label = '密码'
        self.fields['password2'].label = '确认密码'
        # 设置用户名唯一性校验的中文错误信息
        self.fields['username'].error_messages.update({
            'unique': '该用户名已被占用，请更换一个。'
        })
        
        # 设置字段的帮助文本为中文
        self.fields['username'].help_text = '必填。150个字符或者更少。包含字母，数字和仅有的@/./+/-/_符号。'
        self.fields['password1'].help_text = '您的密码不能与其他个人信息太相似。您的密码必须包含至少 8 个字符。您的密码不能是大家都爱用的常见密码。您的密码不能全部为数字。'
        self.fields['password2'].help_text = '为了校验，请输入与上面相同的密码。'
        
        # 设置字段的占位符
        self.fields['username'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': '请输入用户名'
        })
        self.fields['password1'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': '请输入密码'
        })
        self.fields['password2'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': '请再次输入密码'
        })

        # 新增角色字段
        # 允许 学生/教师/管理员 选择
        self.fields['role'] = forms.ChoiceField(
            choices=UserProfile.ROLE_CHOICES,
            label='角色',
            initial=UserProfile.ROLE_STUDENT,
            widget=forms.Select(attrs={'class': 'form-select'})
        )

        # 禁止在注册页选择管理员角色（仅允许 学生/教师）
        allowed_roles = [
            (UserProfile.ROLE_STUDENT, '学生'),
            (UserProfile.ROLE_TEACHER, '教师'),
        ]
        self.fields['role'].choices = allowed_roles

        # 新增邮箱与手机号字段
        self.fields['email'] = forms.EmailField(
            label='邮箱',
            required=False,
            widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': '请输入邮箱'})
        )
        self.fields['phone'] = forms.CharField(
            label='手机号',
            required=False,
            widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': '请输入手机号'})
        )

    def clean_password2(self):
        """校验两次密码，并将密码校验错误翻译为中文。"""
        password1 = self.cleaned_data.get("password1")
        password2 = self.cleaned_data.get("password2")

        if password1 and password2 and password1 != password2:
            raise forms.ValidationError("两次输入的密码不一致。")

        if password2:
            # 传入用户名用于相似性校验
            self.instance.username = self.cleaned_data.get('username')
            try:
                password_validation.validate_password(password2, self.instance)
            except ValidationError as err:
                translated = []
                for msg in err.messages:
                    if msg == "The password is too similar to the username.":
                        translated.append("该密码与用户名过于相似。")
                    elif msg == "This password is too short. It must contain at least 8 characters.":
                        translated.append("该密码太短。至少需要 8 个字符。")
                    elif msg == "This password is too common.":
                        translated.append("该密码过于常见。")
                    elif msg == "This password is entirely numeric.":
                        translated.append("该密码不能全部为数字。")
                    else:
                        translated.append(msg)
                raise forms.ValidationError(translated)

        return password2

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data.get('email', '')
        if commit:
            user.save()
        role = self.cleaned_data.get('role', UserProfile.ROLE_STUDENT)
        phone = self.cleaned_data.get('phone', '')
        if commit:
            UserProfile.objects.create(user=user, role=role, phone=phone)
        else:
            user._pending_role = role
            user._pending_phone = phone
        return user

    def clean_role(self):
        """禁止注册管理员角色。"""
        role = self.cleaned_data.get('role')
        if role == UserProfile.ROLE_ADMIN:
            raise forms.ValidationError('不能通过注册页面创建管理员账号。')
        return role

class ProfileForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # 使用简单的 FileInput，避免显示“Currently: 文件名”
        if 'avatar' in self.fields:
            self.fields['avatar'].widget = forms.FileInput(attrs={'class': 'form-control'})

    class Meta:
        model = UserProfile
        fields = ['phone', 'avatar']
        labels = {
            'phone': '手机号',
            'avatar': '头像',
        }
        widgets = {
            'phone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '请输入手机号'}),
        }

class UserEmailForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['email']
        labels = {
            'email': '邮箱',
        }
        widgets = {
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': '请输入邮箱'}),
        }

    # 仅负责邮箱字段，无额外密码校验/保存逻辑


class ChineseAuthenticationForm(AuthenticationForm):
    """自定义用户登录表单，使用中文提示信息"""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # 设置字段标签为中文
        self.fields['username'].label = '用户名'
        self.fields['password'].label = '密码'
        
        # 设置字段的占位符
        self.fields['username'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': '请输入用户名'
        })
        self.fields['password'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': '请输入密码'
        })
        
        # 设置字段的错误信息为中文
        self.fields['username'].error_messages.update({
            'required': '请输入用户名',
            'invalid': '用户名格式不正确'
        })
        self.fields['password'].error_messages.update({
            'required': '请输入密码',
            'invalid': '密码格式不正确'
        })
    
    def clean(self):
        """重写 clean 方法，提供中文错误信息"""
        username = self.cleaned_data.get('username')
        password = self.cleaned_data.get('password')
        
        if username and password:
            from django.contrib.auth.models import User
            
            # 先尝试获取用户
            try:
                user = User.objects.get(username=username)
                
                # 检查密码格式
                if user.password.startswith('plain$'):
                    # 明文密码验证
                    stored_password = user.password[6:]  # 去掉 'plain$' 前缀
                    if password != stored_password:
                        user = None
                else:
                    # Django 默认密码哈希验证（pbkdf2_sha256 等）
                    if not user.check_password(password):
                        user = None
                        
            except User.DoesNotExist:
                user = None
            
            if user is None:
                raise forms.ValidationError('用户名或密码不正确，请重试。')
            elif not user.is_active:
                raise forms.ValidationError('该账户已被禁用，请联系管理员。')
        
        return self.cleaned_data


class ChinesePasswordChangeForm(PasswordChangeForm):
    """修改密码表单的中文化提示与校验信息。"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['old_password'].label = '当前密码'
        self.fields['new_password1'].label = '新密码'
        self.fields['new_password2'].label = '确认新密码'
        # 新密码帮助文本（中文）
        self.fields['new_password1'].help_text = (
            '密码至少 8 个字符，不能与个人信息过于相似，不能是常见密码，且不能全部为数字。'
        )

    def clean_new_password2(self):
        new_password1 = self.cleaned_data.get('new_password1')
        new_password2 = self.cleaned_data.get('new_password2')
        if new_password1 and new_password2 and new_password1 != new_password2:
            raise forms.ValidationError('两次输入的新密码不一致。')

        if new_password2:
            try:
                password_validation.validate_password(new_password2, self.user)
            except ValidationError as err:
                translated = []
                for msg in err.messages:
                    if msg == "Your password can’t be too similar to your other personal information.":
                        translated.append("密码不能与您的其他个人信息过于相似。")
                    elif msg == "Your password must contain at least 8 characters.":
                        translated.append("密码太短。至少需要 8 个字符。")
                    elif msg == "Your password can’t be a commonly used password.":
                        translated.append("密码过于常见。")
                    elif msg == "Your password can’t be entirely numeric.":
                        translated.append("密码不能全部为数字。")
                    else:
                        translated.append(msg)
                raise forms.ValidationError(translated)

        return new_password2


class AssignmentForm(forms.ModelForm):
    """作业创建/编辑表单"""
    class Meta:
        model = Assignment
        fields = ['title', 'description', 'instructions', 'due_date', 'max_score', 'is_published', 'allow_late_submission']
        labels = {
            'title': '作业标题',
            'description': '作业描述',
            'instructions': '作业要求',
            'due_date': '截止时间',
            'max_score': '满分',
            'is_published': '是否发布',
            'allow_late_submission': '允许迟交',
        }
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '请输入作业标题'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 4, 'placeholder': '请输入作业描述'}),
            'instructions': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': '请输入作业要求（可选）'}),
            'due_date': forms.DateTimeInput(attrs={'class': 'form-control', 'type': 'datetime-local'}),
            'max_score': forms.NumberInput(attrs={'class': 'form-control', 'min': 1, 'max': 1000}),
            'is_published': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'allow_late_submission': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }

    def clean_due_date(self):
        due_date = self.cleaned_data.get('due_date')
        if due_date:
            from django.utils import timezone
            if due_date <= timezone.now():
                raise forms.ValidationError('截止时间必须晚于当前时间。')
        return due_date

    def clean_max_score(self):
        max_score = self.cleaned_data.get('max_score')
        if max_score and max_score <= 0:
            raise forms.ValidationError('满分必须大于0。')
        return max_score


class AssignmentSubmissionForm(forms.ModelForm):
    """学生作业提交表单"""
    class Meta:
        model = AssignmentSubmission
        fields = ['content', 'attachment']
        labels = {
            'content': '提交内容',
            'attachment': '附件',
        }
        widgets = {
            'content': forms.Textarea(attrs={'class': 'form-control', 'rows': 8, 'placeholder': '请输入您的作业内容...'}),
            'attachment': forms.FileInput(attrs={'class': 'form-control', 'accept': '.pdf,.doc,.docx,.txt,.zip,.rar'}),
        }

    def clean_attachment(self):
        attachment = self.cleaned_data.get('attachment')
        if attachment:
            # 限制文件大小（10MB）
            if attachment.size > 10 * 1024 * 1024:
                raise forms.ValidationError('附件大小不能超过10MB。')
            # 限制文件类型
            allowed_extensions = ['.pdf', '.doc', '.docx', '.txt', '.zip', '.rar']
            import os
            ext = os.path.splitext(attachment.name)[1].lower()
            if ext not in allowed_extensions:
                raise forms.ValidationError('只支持PDF、Word、文本、压缩文件格式。')
        return attachment


class AssignmentGradeForm(forms.ModelForm):
    """作业批改表单"""
    class Meta:
        model = AssignmentGrade
        fields = ['score', 'feedback']
        labels = {
            'score': '得分',
            'feedback': '批改反馈',
        }
        widgets = {
            'score': forms.NumberInput(attrs={'class': 'form-control', 'min': 0, 'max': 1000}),
            'feedback': forms.Textarea(attrs={'class': 'form-control', 'rows': 4, 'placeholder': '请输入批改反馈...'}),
        }

    def __init__(self, *args, **kwargs):
        assignment = kwargs.pop('assignment', None)
        super().__init__(*args, **kwargs)
        if assignment:
            self.fields['score'].widget.attrs['max'] = assignment.max_score

    def clean_score(self):
        score = self.cleaned_data.get('score')
        if score is not None and score < 0:
            raise forms.ValidationError('得分不能为负数。')
        return score
