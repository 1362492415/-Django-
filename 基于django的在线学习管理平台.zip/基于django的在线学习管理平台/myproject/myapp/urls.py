# myapp/urls.py

from django.urls import path
from . import views
from django.contrib.auth import views as auth_views
from .forms import ChinesePasswordChangeForm
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('register/', views.register, name='register'),
    path('login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name='logout'),
    # 自定义后台仅管理员登录（避免与Django admin冲突）
    path('backend/login/', views.admin_login, name='admin_login'),
    path('backend/dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('backend/users/', views.admin_users, name='admin_users'),
    path('backend/courses/', views.admin_courses, name='admin_courses'),
    path('backend/videos/', views.admin_videos, name='admin_videos'),
    path('backend/comments/', views.admin_comments, name='admin_comments'),
    path('backend/refunds/', views.admin_refunds, name='admin_refunds'),
    path('', views.home, name='home'),  # 首页
    path('courses/create/', views.create_course, name='course_create'),
    path('courses/', views.learn_courses, name='course_learn'),
    path('teachers/', views.teacher_list, name='teacher_list'),
    path('courses/<int:course_id>/', views.course_detail, name='course_detail'),
    path('video/<int:course_id>/', views.video_player, name='video_player'),
    path('video/<int:course_id>/like/', views.toggle_like, name='toggle_like'),
    path('video/<int:course_id>/favorite/', views.toggle_favorite, name='toggle_favorite'),
    path('video/<int:course_id>/comment/', views.add_comment, name='add_comment'),
    path('my/favorites/', views.my_favorites, name='my_favorites'),
    path('teacher/dashboard/', views.teacher_dashboard, name='teacher_dashboard'),
    path('teacher/<str:username>/', views.teacher_detail, name='teacher_detail'),
    path('courses/edit/<int:course_id>/', views.edit_course, name='edit_course'),
    path('courses/toggle/<int:course_id>/', views.toggle_course_status, name='toggle_course_status'),
    path('courses/delete/<int:course_id>/', views.delete_course, name='delete_course'),
    path('account/settings/', views.account_settings, name='account_settings'),
    path('account/password_change/', auth_views.PasswordChangeView.as_view(
        template_name='myapp/password_change.html',
        success_url='/',
        form_class=ChinesePasswordChangeForm
    ), name='password_change'),
    path('account/password_reset_simple/', views.password_reset_simple, name='password_reset_simple'),
    # 简化：仅保留手机号+邮箱直接重置
    
    # 选课管理相关URL
    path('my-courses/', views.my_courses, name='my_courses'),
    path('my-orders/', views.my_orders, name='my_orders'),
    path('courses/<int:course_id>/enroll/', views.enroll_course, name='enroll_course'),
    path('courses/<int:course_id>/unenroll/', views.unenroll_course, name='unenroll_course'),
    
    # 作业管理相关URL
    path('assignments/', views.student_assignments, name='student_assignments'),
    path('courses/<int:course_id>/assignments/', views.assignment_list, name='assignment_list'),
    path('courses/<int:course_id>/assignments/create/', views.assignment_create, name='assignment_create'),
    path('courses/<int:course_id>/assignments/<int:assignment_id>/edit/', views.assignment_edit, name='assignment_edit'),
    path('courses/<int:course_id>/assignments/<int:assignment_id>/delete/', views.assignment_delete, name='assignment_delete'),
    path('courses/<int:course_id>/assignments/<int:assignment_id>/submissions/', views.assignment_submissions, name='assignment_submissions'),
    path('courses/<int:course_id>/assignments/<int:assignment_id>/submissions/<int:submission_id>/grade/', views.assignment_grade, name='assignment_grade'),
    path('courses/<int:course_id>/assignments/<int:assignment_id>/', views.assignment_detail, name='assignment_detail'),
    path('courses/<int:course_id>/assignments/<int:assignment_id>/submit/', views.assignment_submit, name='assignment_submit'),
    
    # 购买与下载
    path('courses/<int:course_id>/purchase/', views.purchase_course, name='purchase_course'),
    path('my-orders/refund/<str:order_no>/', views.apply_refund, name='apply_refund'),
    path('courses/<int:course_id>/resources/<int:resource_id>/download/', views.download_course_resource, name='download_course_resource'),
    path('courses/lesson/<int:lesson_id>/edit-content/', views.edit_lesson_content, name='edit_lesson_content'),
    path('courses/lesson/progress/', views.update_lesson_progress, name='update_lesson_progress'),
    path('upload_image/', views.upload_image, name='upload_image'),
    path('test/tinymce/', views.test_tinymce, name='test_tinymce'),
]
