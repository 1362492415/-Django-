from django.contrib import admin
from .models import UserPlaintext, UserProfile, TeacherCredential, AdminCredential, Course

@admin.register(UserPlaintext)
class UserPlaintextAdmin(admin.ModelAdmin):
    list_display = ('user', 'plaintext_password', 'created_at')
    search_fields = ('user__username',)

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'role', 'created_at')
    list_filter = ('role',)
    search_fields = ('user__username',)

@admin.register(TeacherCredential)
class TeacherCredentialAdmin(admin.ModelAdmin):
    list_display = ('user', 'username', 'created_at')
    search_fields = ('username', 'user__username')

@admin.register(AdminCredential)
class AdminCredentialAdmin(admin.ModelAdmin):
    list_display = ('user', 'username', 'created_at')
    search_fields = ('username', 'user__username')

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ('title', 'duration', 'created_at')

# Register your models here.
