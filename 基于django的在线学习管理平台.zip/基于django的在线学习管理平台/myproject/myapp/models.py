from django.db import models
import os
import time
import uuid

# Create your models here.


class Course(models.Model):
    STATUS_DRAFT = 'draft'
    STATUS_PUBLISHED = 'published'
    STATUS_ARCHIVED = 'archived'
    
    STATUS_CHOICES = (
        (STATUS_DRAFT, '草稿'),
        (STATUS_PUBLISHED, '已发布'),
        (STATUS_ARCHIVED, '已下架'),
    )

    DIFFICULTY_BEGINNER = 'beginner'
    DIFFICULTY_INTERMEDIATE = 'intermediate'
    DIFFICULTY_ADVANCED = 'advanced'
    
    DIFFICULTY_CHOICES = (
        (DIFFICULTY_BEGINNER, '初级'),
        (DIFFICULTY_INTERMEDIATE, '中级'),
        (DIFFICULTY_ADVANCED, '高级'),
    )
    
    title = models.CharField(max_length=100)
    description = models.TextField()
    duration = models.IntegerField()  # 课程时长（分钟）
    major = models.CharField(max_length=100, blank=True)  # 专业
    difficulty = models.CharField(max_length=16, choices=DIFFICULTY_CHOICES, default=DIFFICULTY_BEGINNER, verbose_name='难度等级')
    is_public = models.BooleanField(default=False)  # 是否公开课
    created_by = models.ForeignKey('auth.User', on_delete=models.CASCADE, related_name='created_courses')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_DRAFT)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    # 视频相关字段（预留）
    video_file = models.FileField(upload_to='course_videos/', blank=True, null=True)
    video_url = models.URLField(blank=True, null=True)  # 外部视频链接
    thumbnail = models.ImageField(upload_to='course_thumbnails/', blank=True, null=True)
    # 付费相关
    price = models.DecimalField(max_digits=10, decimal_places=2, default=0, help_text="课程价格，0表示免费/公开")
    
    # 课程内容相关字段（预留）
    course_content = models.TextField(blank=True, null=True)  # 课程详细内容
    learning_objectives = models.TextField(blank=True, null=True)  # 学习目标
    prerequisites = models.TextField(blank=True, null=True)  # 先修要求

    def __str__(self):
        return self.title


class UnenrollLog(models.Model):
    """退课日志"""
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE, verbose_name="用户")
    course = models.ForeignKey(Course, on_delete=models.CASCADE, verbose_name="课程")
    unenrolled_at = models.DateTimeField(auto_now_add=True, verbose_name="退课时间")
    ip_address = models.GenericIPAddressField(null=True, blank=True, verbose_name="操作IP")

    class Meta:
        verbose_name = '退课日志'
        verbose_name_plural = verbose_name
        ordering = ['-unenrolled_at']

    def __str__(self):
        return f"{self.user.username} 退课 {self.course.title}"


class Chapter(models.Model):
    """课程章节"""
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='chapters')
    title = models.CharField(max_length=200)
    order = models.PositiveIntegerField(default=1)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return f"{self.course.title} - {self.title}"


class Lesson(models.Model):
    """章节内的课节，支持视频或图文课"""
    TYPE_VIDEO = 'video'
    TYPE_TEXT = 'text'
    TYPE_CHOICES = (
        (TYPE_VIDEO, '视频课'),
        (TYPE_TEXT, '图文课'),
    )

    chapter = models.ForeignKey(Chapter, on_delete=models.CASCADE, related_name='lessons')
    title = models.CharField(max_length=200)
    lesson_type = models.CharField(max_length=16, choices=TYPE_CHOICES, default=TYPE_VIDEO)
    order = models.PositiveIntegerField(default=1)
    # 视频/文本内容
    video_file = models.FileField(upload_to='lesson_videos/', blank=True, null=True)
    video_url = models.URLField(blank=True, null=True)
    text_content = models.TextField(blank=True, null=True)
    duration = models.IntegerField(default=0)  # 秒，选填
    is_published = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return f"{self.chapter.title} - {self.title}"


class CourseResource(models.Model):
    """课程级别的资源/课件（如PDF、PPT、ZIP等）"""
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='resources')
    name = models.CharField(max_length=200)
    file = models.FileField(upload_to='course_resources/')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.course.title} - {self.name}"

class Video(models.Model):
    TRANSCODE_PENDING = 'pending'
    TRANSCODE_DONE = 'done'
    TRANSCODE_FAILED = 'failed'

    TRANSCODE_CHOICES = (
        (TRANSCODE_PENDING, '等待处理'),
        (TRANSCODE_DONE, '处理完成'),
        (TRANSCODE_FAILED, '处理失败'),
    )

    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='videos')
    title = models.CharField(max_length=200)
    file = models.FileField(upload_to='course_videos/', blank=True, null=True)
    url = models.URLField(blank=True, null=True)
    cover = models.ImageField(upload_to='course_thumbnails/', blank=True, null=True)
    duration = models.IntegerField(default=0)  # 秒
    is_published = models.BooleanField(default=True)
    transcode_status = models.CharField(max_length=16, choices=TRANSCODE_CHOICES, default=TRANSCODE_PENDING)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.title} - {self.course.title}"


class Comment(models.Model):
    STATUS_PENDING = 'pending'
    STATUS_APPROVED = 'approved'
    STATUS_REJECTED = 'rejected'

    STATUS_CHOICES = (
        (STATUS_PENDING, '待审核'),
        (STATUS_APPROVED, '已通过'),
        (STATUS_REJECTED, '已驳回'),
    )

    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='comments')
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE, related_name='comments')
    content = models.TextField()
    rating = models.PositiveSmallIntegerField(default=5)
    status = models.CharField(max_length=16, choices=STATUS_CHOICES, default=STATUS_PENDING)
    reject_reason = models.CharField(max_length=255, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Comment by {self.user.username} on {self.course.title}"


class VideoLike(models.Model):
    """视频点赞模型"""
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE, related_name='video_likes')
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='likes')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'course')  # 每个用户只能对同一课程点赞一次

    def __str__(self):
        return f"{self.user.username} liked {self.course.title}"


class VideoFavorite(models.Model):
    """视频收藏模型"""
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE, related_name='video_favorites')
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='favorites')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'course')  # 每个用户只能对同一课程收藏一次

    def __str__(self):
        return f"{self.user.username} favorited {self.course.title}"

class UserPlaintext(models.Model):
    """仅用于演示：存储用户的明文密码。严禁生产使用。"""
    user = models.OneToOneField('auth.User', on_delete=models.CASCADE, related_name='plaintext')
    plaintext_password = models.CharField(max_length=128)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=32, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Plaintext for {self.user.username}"


def avatar_upload_path(instance, filename):
    base, ext = os.path.splitext(filename)
    ext = (ext or '').lower()
    user_id = getattr(instance.user, 'id', 'u')
    ts = int(time.time())
    return f"avatars/{user_id}_{ts}{ext}"


class UserProfile(models.Model):
    ROLE_STUDENT = 'student'
    ROLE_TEACHER = 'teacher'
    ROLE_ADMIN = 'admin'

    ROLE_CHOICES = (
        (ROLE_STUDENT, '学生'),
        (ROLE_TEACHER, '教师'),
        (ROLE_ADMIN, '管理员'),
    )

    user = models.OneToOneField('auth.User', on_delete=models.CASCADE, related_name='profile')
    role = models.CharField(max_length=16, choices=ROLE_CHOICES, default=ROLE_STUDENT)
    phone = models.CharField(max_length=32, blank=True)
    avatar = models.ImageField(upload_to=avatar_upload_path, blank=True, null=True)
    title = models.CharField(max_length=100, blank=True, verbose_name='职称/头衔')
    bio = models.TextField(blank=True, verbose_name='个人简介')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.user.username} - {self.get_role_display()}"


class TeacherCredential(models.Model):
    """仅演示用途：老师账号的明文凭据存储（严禁生产使用）。"""
    user = models.OneToOneField('auth.User', on_delete=models.CASCADE, related_name='teacher_credential')
    username = models.CharField(max_length=150)
    plaintext_password = models.CharField(max_length=128)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=32, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"TeacherCredential({self.username})"


class AdminCredential(models.Model):
    """仅演示用途：管理员账号的明文凭据存储（严禁生产使用）。"""
    user = models.OneToOneField('auth.User', on_delete=models.CASCADE, related_name='admin_credential')
    username = models.CharField(max_length=150)
    plaintext_password = models.CharField(max_length=128)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=32, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"AdminCredential({self.username})"


class Assignment(models.Model):
    """作业模型"""
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='assignments')
    title = models.CharField(max_length=200, verbose_name='作业标题')
    description = models.TextField(verbose_name='作业描述')
    instructions = models.TextField(blank=True, null=True, verbose_name='作业要求')
    due_date = models.DateTimeField(verbose_name='截止时间')
    max_score = models.PositiveIntegerField(default=100, verbose_name='满分')
    is_published = models.BooleanField(default=False, verbose_name='是否发布')
    allow_late_submission = models.BooleanField(default=False, verbose_name='允许迟交')
    created_by = models.ForeignKey('auth.User', on_delete=models.CASCADE, related_name='created_assignments')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.course.title} - {self.title}"

    @property
    def is_overdue(self):
        from django.utils import timezone
        return timezone.now() > self.due_date


class AssignmentSubmission(models.Model):
    """学生作业提交模型"""
    assignment = models.ForeignKey(Assignment, on_delete=models.CASCADE, related_name='submissions')
    student = models.ForeignKey('auth.User', on_delete=models.CASCADE, related_name='assignment_submissions')
    content = models.TextField(verbose_name='提交内容')
    attachment = models.FileField(upload_to='assignment_submissions/', blank=True, null=True, verbose_name='附件')
    submitted_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_late = models.BooleanField(default=False)

    class Meta:
        unique_together = ('assignment', 'student')  # 每个学生只能提交一次作业
        ordering = ['-submitted_at']

    def __str__(self):
        return f"{self.student.username} - {self.assignment.title}"

    def save(self, *args, **kwargs):
        # 检查是否迟交
        if self.assignment and not self.assignment.allow_late_submission:
            from django.utils import timezone
            self.is_late = timezone.now() > self.assignment.due_date
        super().save(*args, **kwargs)


class AssignmentGrade(models.Model):
    """作业批改成绩模型"""
    submission = models.OneToOneField(AssignmentSubmission, on_delete=models.CASCADE, related_name='grade')
    grader = models.ForeignKey('auth.User', on_delete=models.CASCADE, related_name='graded_assignments')
    score = models.PositiveIntegerField(verbose_name='得分')
    feedback = models.TextField(blank=True, null=True, verbose_name='批改反馈')
    graded_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-graded_at']

    def __str__(self):
        return f"{self.submission.student.username} - {self.submission.assignment.title} - {self.score}分"

    @property
    def percentage(self):
        return round((self.score / self.submission.assignment.max_score) * 100, 1)


class CourseEnrollment(models.Model):
    """学生选课记录模型"""
    student = models.ForeignKey('auth.User', on_delete=models.CASCADE, related_name='enrollments')
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='enrollments')
    enrolled_at = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True, verbose_name='是否有效')

    class Meta:
        unique_together = ('student', 'course')  # 每个学生只能选同一门课程一次
        ordering = ['-enrolled_at']

    def __str__(self):
        return f"{self.student.username} - {self.course.title}"

    @property
    def progress_percentage(self):
        """计算学习进度百分比（基于已完成的课节）"""
        total_lessons = Lesson.objects.filter(chapter__course=self.course, is_published=True).count()
        if total_lessons == 0:
            return 0
        completed_lessons = LessonProgress.objects.filter(
            user=self.student, 
            lesson__chapter__course=self.course,
            is_completed=True
        ).count()
        return int((completed_lessons / total_lessons) * 100)


class CoursePurchase(models.Model):
    """课程购买记录（支付成功后生成）"""
    STATUS_PAID = 'paid'
    STATUS_REFUNDED = 'refunded'
    STATUS_CLOSED = 'closed'

    STATUS_CHOICES = (
        (STATUS_PAID, '已支付'),
        (STATUS_REFUNDED, '已退款'),
        (STATUS_CLOSED, '交易关闭'),
    )

    user = models.ForeignKey('auth.User', on_delete=models.CASCADE, related_name='purchases')
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='purchases')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    paid_at = models.DateTimeField(auto_now_add=True)
    
    # 新增字段
    order_no = models.CharField(max_length=64, unique=True, default=uuid.uuid4, editable=False)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_PAID)
    payment_method = models.CharField(max_length=20, default='alipay')

    class Meta:
        unique_together = ('user', 'course')
        ordering = ['-paid_at']

    def __str__(self):
        return f"{self.user.username} purchased {self.course.title} for {self.amount}"


class RefundApplication(models.Model):
    """课程退款申请模型"""
    STATUS_PENDING = 'pending'
    STATUS_APPROVED = 'approved'
    STATUS_REJECTED = 'rejected'
    
    STATUS_CHOICES = (
        (STATUS_PENDING, '待处理'),
        (STATUS_APPROVED, '已同意'),
        (STATUS_REJECTED, '已驳回'),
    )
    
    REASON_CHOICES = (
        ('content_mismatch', '课程内容与描述不符'),
        ('poor_quality', '讲师授课质量不佳'),
        ('personal_reasons', '个人原因不想学了'),
        ('technical_issues', '视频播放卡顿等技术问题'),
        ('other', '其他原因'),
    )

    application_no = models.CharField(max_length=64, unique=True, editable=False, verbose_name="申请单号")
    purchase = models.OneToOneField(CoursePurchase, on_delete=models.CASCADE, related_name='refund_application', verbose_name="关联订单")
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE, related_name='refund_applications', verbose_name="申请人")
    reason = models.CharField(max_length=100, verbose_name="退款原因")
    description = models.TextField(verbose_name="退款说明")
    contact_info = models.CharField(max_length=100, verbose_name="联系方式")
    refund_amount = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="预计退款金额")
    progress_at_refund = models.IntegerField(default=0, help_text="申请退款时的学习进度(%)", verbose_name="申请时进度")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_PENDING, verbose_name="处理状态")
    admin_remark = models.TextField(blank=True, null=True, verbose_name="管理员备注")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="申请时间")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="更新时间")

    class Meta:
        ordering = ['-created_at']
        verbose_name = '退款申请'
        verbose_name_plural = verbose_name

    def get_reason_label(self):
        """获取退款原因的显示文本"""
        reasons_dict = dict(self.REASON_CHOICES)
        return reasons_dict.get(self.reason, self.reason)

    def save(self, *args, **kwargs):
        if not self.application_no:
            import time, uuid
            self.application_no = f"REF{int(time.time())}{uuid.uuid4().hex[:6].upper()}"
        super().save(*args, **kwargs)

    def __str__(self):
        return f"退款申请 {self.application_no} - {self.purchase.course.title}"


class LessonProgress(models.Model):
    """学生课节学习进度"""
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE, related_name='lesson_progress')
    lesson = models.ForeignKey(Lesson, on_delete=models.CASCADE, related_name='progress')
    is_completed = models.BooleanField(default=False)
    # 播放进度（秒）
    current_time = models.IntegerField(default=0, help_text="当前播放时间(秒)")
    # 最大播放进度（秒），防止用户拖拽跳过
    max_watched_time = models.IntegerField(default=0, help_text="已观看的最大时间(秒)")
    # 视频总时长（秒），冗余存储方便计算百分比
    duration = models.IntegerField(default=0, help_text="视频总时长(秒)")
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('user', 'lesson')

    def __str__(self):
        return f"{self.user.username} - {self.lesson.title} - {'Completed' if self.is_completed else 'In Progress'}"


class Banner(models.Model):
    """首页轮播图"""
    title = models.CharField(max_length=100, verbose_name='标题')
    subtitle = models.CharField(max_length=200, blank=True, verbose_name='副标题')
    image = models.ImageField(upload_to='banners/', verbose_name='图片')
    url = models.URLField(blank=True, verbose_name='跳转链接')
    order = models.IntegerField(default=0, verbose_name='排序')
    is_active = models.BooleanField(default=True, verbose_name='启用')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['order', '-created_at']

    def __str__(self):
        return self.title


class Announcement(models.Model):
    """系统公告"""
    TYPE_INFO = 'info'
    TYPE_WARNING = 'warning'
    TYPE_DANGER = 'danger'
    TYPE_SUCCESS = 'success'
    
    TYPE_CHOICES = (
        (TYPE_INFO, '普通通知'),
        (TYPE_WARNING, '重要提醒'),
        (TYPE_DANGER, '紧急通知'),
        (TYPE_SUCCESS, '成功消息'),
    )

    title = models.CharField(max_length=200, verbose_name='标题')
    content = models.TextField(verbose_name='内容')
    type = models.CharField(max_length=20, choices=TYPE_CHOICES, default=TYPE_INFO, verbose_name='类型')
    is_active = models.BooleanField(default=True, verbose_name='启用')
    start_time = models.DateTimeField(null=True, blank=True, verbose_name='开始显示时间')
    end_time = models.DateTimeField(null=True, blank=True, verbose_name='结束显示时间')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.title
