from django.contrib.auth.hashers import BasePasswordHasher
from django.utils.translation import gettext_noop as _

class PlainTextPasswordHasher(BasePasswordHasher):
    """极不安全：直接把密码明文存储在数据库。仅限教学演示。"""
    algorithm = "plain"

    def salt(self):
        return ""  # 不使用盐

    def encode(self, password, salt):
        return f"{self.algorithm}${password}"

    def verify(self, password, encoded):
        if not encoded or "$" not in encoded:
            return False
        algo, hash_pass = encoded.split("$", 1)
        return algo == self.algorithm and password == hash_pass

    def safe_summary(self, encoded):
        algo, hash_pass = encoded.split("$", 1)
        return {
            _("algorithm"): algo,
            _("hash"): hash_pass[:2] + "***",
        }
