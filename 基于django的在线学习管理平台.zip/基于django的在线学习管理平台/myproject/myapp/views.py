
# myapp/views.py

from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from urllib.parse import quote
from django.contrib.auth import login, authenticate, logout
from .forms import ChineseUserCreationForm, ChineseAuthenticationForm, ProfileForm, UserEmailForm, AssignmentForm, AssignmentSubmissionForm, AssignmentGradeForm
from functools import wraps
from django.http import HttpResponseForbidden
from django.db.models import Sum, Count
from .models import UserProfile, Course, Video, Comment, VideoLike, VideoFavorite, Chapter, Lesson, CourseResource, LessonProgress
from .models import UserPlaintext, TeacherCredential, AdminCredential, UserProfile, Assignment, AssignmentSubmission, AssignmentGrade, CourseEnrollment, CoursePurchase, Banner, Announcement, RefundApplication
from django.contrib.auth.models import User
from django.contrib import messages
from django.core.paginator import Paginator
from django.db.models import Q, Case, When, IntegerField, Count, Sum
from django.db.models.functions import TruncDate
import json
from django.views.decorators.http import require_POST
from django.http import JsonResponse
def force_login(request):
    """强制登录，自动携带 next 参数"""
    login_url = reverse('login')
    full_path = quote(request.get_full_path())
    return redirect(f"{login_url}?next={full_path}")

# 用户注册视图
def register(request):
    if request.method == 'POST':
        form = ChineseUserCreationForm(request.POST)
        if form.is_valid():
            # 保存新用户
            user = form.save()
            # 仅用于演示：保存明文密码（严禁生产使用）
            try:
                UserPlaintext.objects.create(
                    user=user,
                    plaintext_password=form.cleaned_data.get('password1', ''),
                    email=form.cleaned_data.get('email', ''),
                    phone=form.cleaned_data.get('phone', ''),
                )
            except Exception:
                pass
            # 若为教师角色，保存到教师明文凭据表（仅演示）
            try:
                profile = getattr(user, 'profile', None)
                if profile and profile.role == UserProfile.ROLE_TEACHER:
                    TeacherCredential.objects.create(
                        user=user,
                        username=user.username,
                        plaintext_password=form.cleaned_data.get('password1', ''),
                        email=form.cleaned_data.get('email', ''),
                        phone=form.cleaned_data.get('phone', ''),
                    )
            except Exception:
                pass
            # 若为管理员角色，保存到管理员明文凭据表（仅演示）
            try:
                profile = getattr(user, 'profile', None)
                if profile and profile.role == UserProfile.ROLE_ADMIN:
                    AdminCredential.objects.create(
                        user=user,
                        username=user.username,
                        plaintext_password=form.cleaned_data.get('password1', ''),
                        email=form.cleaned_data.get('email', ''),
                        phone=form.cleaned_data.get('phone', ''),
                    )
            except Exception:
                pass
            # 登录新用户
            login(request, user)
            next_url = request.GET.get('next', 'home')
            return redirect(next_url)
    else:
        form = ChineseUserCreationForm()

    return render(request, 'myapp/register.html', {'form': form})
# 用户登录视图
def user_login(request):
    if request.method == 'POST':
        form = ChineseAuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                # 确保用户有 profile
                profile = getattr(user, 'profile', None)
                if profile is None:
                    from .models import UserProfile
                    UserProfile.objects.create(user=user, role=UserProfile.ROLE_STUDENT)
                next_url = request.GET.get('next', 'home')
                return redirect(next_url)
        else:
            # 打印表单错误以便调试
            print("登录表单验证失败:", form.errors)
    else:
        form = ChineseAuthenticationForm()

    return render(request, 'myapp/welcome.html', {'form': form})
# 用户登出视图
def user_logout(request):
    logout(request)
    return redirect('home')  # 登出后重定向到主页

# 管理员登录视图（仅管理员可登录）
def admin_login(request):
    if request.method == 'POST':
        form = ChineseAuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                profile = getattr(user, 'profile', None)
                # 允许：有管理员角色的用户；或无profile但为超级管理员
                if (profile and profile.role == UserProfile.ROLE_ADMIN) or (not profile and user.is_superuser):
                    login(request, user)
                    return redirect('admin_dashboard')
                else:
                    form.add_error(None, '仅管理员可登录后台')
    else:
        form = ChineseAuthenticationForm()

    return render(request, 'myapp/admin_login.html', {'form': form})
def home(request):
    """
    首页视图：展示轮播图、公告、推荐课程和最新课程
    """
    # 获取启用的轮播图
    banners = Banner.objects.filter(is_active=True)
    
    # 获取有效的公告 (在当前时间范围内)
    from django.utils import timezone
    now = timezone.now()
    announcements = Announcement.objects.filter(
        is_active=True
    ).filter(
        Q(start_time__isnull=True) | Q(start_time__lte=now)
    ).filter(
        Q(end_time__isnull=True) | Q(end_time__gte=now)
    )[:5]  # 只显示最新的5条

    # 已登录用户显示课程主页
    # 专业筛选
    major = request.GET.get('major', '').strip()
    courses_qs = Course.objects.filter(status=Course.STATUS_PUBLISHED).order_by('-created_at')
    if major:
        courses_qs = courses_qs.filter(major=major)
    public_courses = courses_qs.filter(is_public=True)[:6]
    latest_courses = courses_qs[:6]
    # 简单讲师：取有profile且角色为教师或管理员的用户
    teachers = User.objects.filter(
        Q(profile__role=UserProfile.ROLE_TEACHER) | 
        Q(profile__role=UserProfile.ROLE_ADMIN) |
        Q(is_superuser=True)
    ).distinct()[:6]
    majors = Course.objects.exclude(major='').values_list('major', flat=True).distinct()
    
    # 推荐课程（示例：按价格降序，或者您可以添加专门的 is_recommended 字段）
    featured_courses = courses_qs.order_by('-price')[:3]

    return render(request, 'myapp/home.html', {
        'banners': banners,
        'announcements': announcements,
        'latest_courses': latest_courses,
        'public_courses': public_courses,
        'teachers': teachers,
        'majors': majors,
        'current_major': major,
        'featured_courses': featured_courses,
    })


def account_settings(request):
    if not request.user.is_authenticated:
        return force_login(request)
    profile = getattr(request.user, 'profile', None)
    if profile is None:
        profile = UserProfile.objects.create(user=request.user)
    if request.method == 'POST':
        pform = ProfileForm(request.POST, request.FILES, instance=profile)
        uform = UserEmailForm(request.POST, instance=request.user)
        if pform.is_valid() and uform.is_valid():
            pform.save()
            uform.save()
            return redirect('account_settings')
    else:
        pform = ProfileForm(instance=profile)
        uform = UserEmailForm(instance=request.user)
    return render(request, 'myapp/account_settings.html', {'pform': pform, 'uform': uform})


def role_required(allowed_roles):
    def decorator(view_func):
        @wraps(view_func)
        def _wrapped(request, *args, **kwargs):
            if not request.user.is_authenticated:
                return force_login(request)
            profile = getattr(request.user, 'profile', None)
            if request.user.is_superuser or (profile and profile.role in allowed_roles):
                return view_func(request, *args, **kwargs)
            return HttpResponseForbidden('无权限访问该页面')
        return _wrapped
    return decorator


def _admin_required(view_func):
    return role_required([UserProfile.ROLE_ADMIN, UserProfile.ROLE_TEACHER])(view_func)


@role_required([UserProfile.ROLE_TEACHER, UserProfile.ROLE_ADMIN])
def create_course(request):
    """
    极简版创建课程：仅需输入标题，直接跳转到编辑页。
    """
    if request.method == 'POST':
        title = request.POST.get('title', '').strip()
        if title:
            # 创建草稿课程
            course = Course.objects.create(
                title=title,
                created_by=request.user,
                status=Course.STATUS_DRAFT,
                duration=0,
                price=0
            )
            messages.success(request, '课程已创建，请完善详细信息。')
            return redirect('edit_course', course_id=course.id)
        else:
            messages.error(request, '请输入课程标题')
            
    return render(request, 'myapp/course_create_simple.html')


def learn_courses(request):
    """课程列表页（支持多维筛选）"""
    # 基础筛选：仅显示已发布
    courses = Course.objects.filter(status=Course.STATUS_PUBLISHED)
    
    # 获取筛选参数
    q = request.GET.get('q', '').strip()
    major = request.GET.get('major', '').strip()
    difficulty = request.GET.get('difficulty', '').strip()
    price_range = request.GET.get('price', '').strip()  # free, paid
    sort = request.GET.get('sort', 'newest')  # newest, popular
    
    # 应用筛选
    if q:
        courses = courses.filter(Q(title__icontains=q) | Q(description__icontains=q))
    
    if major:
        courses = courses.filter(major=major)
        
    if difficulty:
        courses = courses.filter(difficulty=difficulty)
        
    if price_range == 'free':
        courses = courses.filter(price=0)
    elif price_range == 'paid':
        courses = courses.filter(price__gt=0)
        
    # 排序
    if sort == 'popular':
        # 简单按收藏数排序
        courses = courses.annotate(fav_count=Count('favorites')).order_by('-fav_count')
    else:
        # 默认按时间倒序
        courses = courses.order_by('-created_at')

    # 获取选项数据
    majors = Course.objects.exclude(major='').values_list('major', flat=True).distinct()
    
    # 分页
    paginator = Paginator(courses, 9)
    page_obj = paginator.get_page(request.GET.get('page', 1))
    
    # 获取用户已选的课程（如果已登录）
    enrolled_course_ids = set()
    if request.user.is_authenticated:
        enrolled_course_ids = set(CourseEnrollment.objects.filter(
            student=request.user,
            is_active=True
        ).values_list('course_id', flat=True))
    
    return render(request, 'myapp/course_learn.html', { 
        'page_obj': page_obj,  # 使用分页对象
        'user_authenticated': request.user.is_authenticated,
        'majors': majors,
        'current_major': major,
        'current_difficulty': difficulty,
        'current_price': price_range,
        'current_sort': sort,
        'q': q,
        'enrolled_course_ids': enrolled_course_ids,
        'difficulty_choices': Course.DIFFICULTY_CHOICES,
    })


@role_required([UserProfile.ROLE_TEACHER, UserProfile.ROLE_ADMIN])
def teacher_dashboard(request):
    """教师仪表板 - 我的课程"""
    courses = Course.objects.filter(created_by=request.user).order_by('-created_at')
    
    # 统计各种状态的课程数量
    total_courses = courses.count()
    published_courses = courses.filter(status=Course.STATUS_PUBLISHED).count()
    draft_courses = courses.filter(status=Course.STATUS_DRAFT).count()
    archived_courses = courses.filter(status=Course.STATUS_ARCHIVED).count()
    
    return render(request, 'myapp/teacher_dashboard.html', {
        'courses': courses,
        'total_courses': total_courses,
        'published_courses': published_courses,
        'draft_courses': draft_courses,
        'archived_courses': archived_courses,
    })


@role_required([UserProfile.ROLE_TEACHER, UserProfile.ROLE_ADMIN])
def edit_course(request, course_id):
    """编辑课程"""
    try:
        course = Course.objects.get(id=course_id, created_by=request.user)
    except Course.DoesNotExist:
        return HttpResponseForbidden('课程不存在或无权限编辑')
    
    if request.method == 'POST':
        action = request.POST.get('action', '').strip()
        # 课程基础信息保存
        if action == '' or action == 'save_course':
            course.title = request.POST.get('title', '').strip()
            course.description = request.POST.get('description', '').strip()
            course.duration = int(request.POST.get('duration', 0))
            course.major = request.POST.get('major', '').strip()
            course.difficulty = request.POST.get('difficulty', Course.DIFFICULTY_BEGINNER)
            course.is_public = request.POST.get('is_public') == '1'
            course.status = request.POST.get('status', Course.STATUS_DRAFT)
            # 处理价格字段
            try:
                course.price = float(request.POST.get('price', 0))
            except ValueError:
                course.price = 0
            if 'video_file' in request.FILES:
                course.video_file = request.FILES['video_file']
            if 'thumbnail' in request.FILES:
                course.thumbnail = request.FILES['thumbnail']
            course.video_url = request.POST.get('video_url', '').strip()
            course.course_content = request.POST.get('course_content', '').strip()
            course.learning_objectives = request.POST.get('learning_objectives', '').strip()
            course.prerequisites = request.POST.get('prerequisites', '').strip()
            course.save()
            messages.success(request, '课程信息已保存')
            return redirect('edit_course', course_id=course.id)
        # 章节/课节/资源操作
        if action == 'add_chapter':
            title = request.POST.get('chapter_title', '').strip()
            order = int(request.POST.get('chapter_order', '1') or 1)
            if title:
                Chapter.objects.create(course=course, title=title, order=order)
            return redirect('edit_course', course_id=course.id)
        if action == 'delete_chapter':
            cid = request.POST.get('chapter_id')
            Chapter.objects.filter(id=cid, course=course).delete()
            return redirect('edit_course', course_id=course.id)
        if action == 'add_lesson':
            cid = request.POST.get('chapter_id')
            title = request.POST.get('lesson_title', '').strip()
            ltype = request.POST.get('lesson_type', Lesson.TYPE_VIDEO)
            order = int(request.POST.get('lesson_order', '1') or 1)
            text = request.POST.get('text_content', '').strip()
            video_url = request.POST.get('lesson_video_url', '').strip()
            video_file = request.FILES.get('lesson_video_file')
            try:
                chapter = Chapter.objects.get(id=cid, course=course)
            except Chapter.DoesNotExist:
                messages.error(request, '章节不存在，无法新增课节')
                return redirect('edit_course', course_id=course.id)
            lesson = Lesson.objects.create(
                chapter=chapter,
                title=title or '未命名课节',
                lesson_type=ltype,
                order=order,
                text_content=text if ltype == Lesson.TYPE_TEXT else '',
                video_url=video_url if ltype == Lesson.TYPE_VIDEO else '',
            )
            if ltype == Lesson.TYPE_VIDEO and video_file:
                lesson.video_file = video_file
                lesson.save()
            messages.success(request, '课节已新增')
            return redirect('edit_course', course_id=course.id)
        if action == 'delete_lesson':
            lid = request.POST.get('lesson_id')
            Lesson.objects.filter(id=lid, chapter__course=course).delete()
            messages.success(request, '课节已删除')
            return redirect('edit_course', course_id=course.id)
        if action == 'update_lesson':
            lid = request.POST.get('lesson_id')
            try:
                lesson = Lesson.objects.get(id=lid, chapter__course=course)
            except Lesson.DoesNotExist:
                messages.error(request, '课节不存在或无权限编辑')
                return redirect('edit_course', course_id=course.id)
            lesson.title = request.POST.get('edit_lesson_title', lesson.title).strip() or lesson.title
            try:
                lesson.order = int(request.POST.get('edit_lesson_order', lesson.order) or lesson.order)
            except Exception:
                pass
            new_type = request.POST.get('edit_lesson_type', lesson.lesson_type)
            lesson.lesson_type = new_type if new_type in [Lesson.TYPE_VIDEO, Lesson.TYPE_TEXT] else lesson.lesson_type
            # 更新内容
            if lesson.lesson_type == Lesson.TYPE_TEXT:
                lesson.text_content = request.POST.get('edit_text_content', '').strip()
                # 清空视频信息
                lesson.video_url = ''
                if request.POST.get('clear_video_file') == '1':
                    lesson.video_file = None
            else:
                lesson.video_url = request.POST.get('edit_lesson_video_url', '').strip()
                if 'edit_lesson_video_file' in request.FILES:
                    lesson.video_file = request.FILES['edit_lesson_video_file']
                # 文本内容清空
                lesson.text_content = ''
            lesson.save()
            messages.success(request, '课节已更新')
            return redirect('edit_course', course_id=course.id)
        if action == 'add_resource':
            name = request.POST.get('res_name', '').strip() or '课件'
            file = request.FILES.get('res_file')
            if file:
                CourseResource.objects.create(course=course, name=name, file=file)
            return redirect('edit_course', course_id=course.id)
        if action == 'delete_resource':
            rid = request.POST.get('res_id')
            CourseResource.objects.filter(id=rid, course=course).delete()
            return redirect('edit_course', course_id=course.id)
    
    return render(request, 'myapp/course_edit.html', {
        'course': course,
        'status_choices': Course.STATUS_CHOICES,
        'chapters': Chapter.objects.filter(course=course).prefetch_related('lessons'),
        'resources': CourseResource.objects.filter(course=course),
        'Lesson': Lesson,  # 供模板判断类型
    })


@role_required([UserProfile.ROLE_TEACHER, UserProfile.ROLE_ADMIN])
def toggle_course_status(request, course_id):
    """切换课程状态（上架/下架）"""
    try:
        course = Course.objects.get(id=course_id, created_by=request.user)
        if course.status == Course.STATUS_PUBLISHED:
            course.status = Course.STATUS_ARCHIVED
        else:
            course.status = Course.STATUS_PUBLISHED
        course.save()
    except Course.DoesNotExist:
        return HttpResponseForbidden('课程不存在或无权限操作')
    
    return redirect('teacher_dashboard')


@role_required([UserProfile.ROLE_TEACHER, UserProfile.ROLE_ADMIN])
def delete_course(request, course_id):
    """删除课程"""
    try:
        course = Course.objects.get(id=course_id, created_by=request.user)
        course.delete()
    except Course.DoesNotExist:
        return HttpResponseForbidden('课程不存在或无权限操作')
    
    return redirect('teacher_dashboard')


from django.db.models import Avg

def course_detail(request, course_id):
    """课程详情页面"""
    try:
        course = Course.objects.prefetch_related('chapters__lessons').get(id=course_id, status=Course.STATUS_PUBLISHED)
    except Course.DoesNotExist:
        return HttpResponseForbidden('课程不存在或未发布')
    
    # 获取用户对当前课程的收藏状态
    user_favorited = False
    user_enrolled = False
    user_purchased = False
    if request.user.is_authenticated:
        user_favorited = VideoFavorite.objects.filter(user=request.user, course=course).exists()
        user_enrolled = CourseEnrollment.objects.filter(
            student=request.user,
            course=course,
            is_active=True
        ).exists()
        user_purchased = CoursePurchase.objects.filter(user=request.user, course=course, status=CoursePurchase.STATUS_PAID).exists()
    
    # 获取统计数据
    favorite_count = VideoFavorite.objects.filter(course=course).count()
    
    # 计算课程评分
    avg_rating = Comment.objects.filter(course=course).aggregate(Avg('rating'))['rating__avg'] or 0
    avg_rating = round(avg_rating, 1)

    # 计算学习进度
    progress_percent = 0
    if request.user.is_authenticated:
        total_lessons = Lesson.objects.filter(chapter__course=course).count()
        if total_lessons > 0:
            completed_lessons = LessonProgress.objects.filter(
                user=request.user, 
                lesson__chapter__course=course, 
                is_completed=True
            ).count()
            progress_percent = int((completed_lessons / total_lessons) * 100)
    
    # 获取学生已选课程ID列表（用于判断是否已选课）
    enrolled_course_ids = []
    if request.user.is_authenticated:
        enrolled_course_ids = list(CourseEnrollment.objects.filter(
            student=request.user,
            is_active=True
        ).values_list('course_id', flat=True))
    
    return render(request, 'myapp/course_detail.html', {
        'course': course,
        'user_authenticated': request.user.is_authenticated,
        'user_favorited': user_favorited,
        'user_enrolled': user_enrolled,
        'user_purchased': user_purchased,
        'enrolled_course_ids': enrolled_course_ids,
        'favorite_count': favorite_count,
        'progress_percent': progress_percent,
        'avg_rating': avg_rating,
    })


def teacher_list(request):
    """讲师列表"""
    q = request.GET.get('q', '').strip()
    sort = request.GET.get('sort', 'course_count')  # 默认按课程数排序
    
    # 获取所有教师和管理员
    teachers = User.objects.filter(
        Q(profile__role=UserProfile.ROLE_TEACHER) | 
        Q(profile__role=UserProfile.ROLE_ADMIN) |
        Q(is_superuser=True)
    ).distinct()
    
    if q:
        teachers = teachers.filter(Q(username__icontains=q) | Q(profile__bio__icontains=q))
    
    # 标注课程数量
    teachers = teachers.annotate(course_count=Count('created_courses'))
    
    # 过滤掉没有创建任何课程的管理员/讲师（可选，这里保留全部）
    # teachers = teachers.filter(course_count__gt=0)
    
    if sort == 'course_count':
        teachers = teachers.order_by('-course_count')
    elif sort == 'newest':
        teachers = teachers.order_by('-date_joined')
    
    paginator = Paginator(teachers, 12)
    page_obj = paginator.get_page(request.GET.get('page', 1))
    
    return render(request, 'myapp/teacher_list.html', {
        'page_obj': page_obj,
        'q': q,
        'sort': sort,
    })


@_admin_required
def admin_dashboard(request):
    profile = getattr(request.user, 'profile', None)
    is_teacher = profile and profile.role == UserProfile.ROLE_TEACHER

    if is_teacher:
        # 教师仅看自己的数据
        total_courses = Course.objects.filter(created_by=request.user).count()
        published_courses = Course.objects.filter(created_by=request.user, status=Course.STATUS_PUBLISHED).count()
        archived_courses = Course.objects.filter(created_by=request.user, status=Course.STATUS_ARCHIVED).count()
        # 教师的学生数：购买了自己课程的学生去重
        students = User.objects.filter(enrollments__course__created_by=request.user).distinct().count()
        # 教师不看全平台讲师数，可以显示自己的总收入
        total_revenue = CoursePurchase.objects.filter(course__created_by=request.user).aggregate(Sum('amount'))['amount__sum'] or 0
        
        # 教师图表：自己的每日订单数
        daily_orders = CoursePurchase.objects.filter(course__created_by=request.user).annotate(date=TruncDate('paid_at')).values('date').annotate(count=Count('id')).order_by('date')
        chart_label = "每日订单"
        chart_data = {
            'labels': [d['date'].strftime('%Y-%m-%d') for d in daily_orders],
            'data': [d['count'] for d in daily_orders]
        }
        
        # 课程销量排行
        course_sales = Course.objects.filter(created_by=request.user).annotate(sales=Count('purchases')).order_by('-sales')[:5]
        pie_label = "课程销量"
        pie_data = {
            'labels': [c.title for c in course_sales],
            'data': [c.sales for c in course_sales]
        }
        
        # 待处理退款申请数
        pending_refunds = RefundApplication.objects.filter(purchase__course__created_by=request.user, status=RefundApplication.STATUS_PENDING).count()
        
        context = {
            'is_teacher': True,
            'total_courses': total_courses,
            'published_courses': published_courses,
            'archived_courses': archived_courses,
            'students': students,
            'total_revenue': total_revenue,
            'pending_refunds': pending_refunds,
            'daily_users_json': json.dumps(chart_data),
            'course_majors_json': json.dumps(pie_data),
            'chart_label': chart_label,
            'pie_label': pie_label,
        }
    else:
        # 管理员看全平台
        total_users = User.objects.count()
        total_courses = Course.objects.count()
        published_courses = Course.objects.filter(status=Course.STATUS_PUBLISHED).count()
        archived_courses = Course.objects.filter(status=Course.STATUS_ARCHIVED).count()
        teachers = User.objects.filter(profile__role=UserProfile.ROLE_TEACHER).count()
        students = User.objects.filter(profile__role=UserProfile.ROLE_STUDENT).count()

        # 数据统计图表数据
        # 1. 每日新增用户（最近30天）
        daily_users = User.objects.annotate(date=TruncDate('date_joined')).values('date').annotate(count=Count('id')).order_by('date')
        daily_users_data = {
            'labels': [d['date'].strftime('%Y-%m-%d') for d in daily_users],
            'data': [d['count'] for d in daily_users]
        }

        # 2. 课程专业分布
        course_majors = Course.objects.exclude(major='').values('major').annotate(count=Count('id'))
        course_majors_data = {
            'labels': [d['major'] for d in course_majors],
            'data': [d['count'] for d in course_majors]
        }
        
        # 待处理退款申请数
        pending_refunds = RefundApplication.objects.filter(status=RefundApplication.STATUS_PENDING).count()

        context = {
            'is_teacher': False,
            'total_users': total_users,
            'total_courses': total_courses,
            'published_courses': published_courses,
            'archived_courses': archived_courses,
            'teachers': teachers,
            'students': students,
            'pending_refunds': pending_refunds,
            'daily_users_json': json.dumps(daily_users_data),
            'course_majors_json': json.dumps(course_majors_data),
            'chart_label': "每日新增用户",
            'pie_label': "课程专业分布",
        }

    return render(request, 'myapp/admin_dashboard.html', context)





@_admin_required
def admin_users(request):
    profile = getattr(request.user, 'profile', None)
    if profile.role != UserProfile.ROLE_ADMIN:
        return HttpResponseForbidden('仅管理员可访问')

    q = request.GET.get('q', '').strip()
    role = request.GET.get('role', '').strip()  # admin/teacher/student
    users = User.objects.all()
    if q:
        users = users.filter(Q(username__icontains=q) | Q(email__icontains=q))
    # 角色筛选（包含无profile但超级管理员的情况）
    if role in [UserProfile.ROLE_ADMIN, UserProfile.ROLE_TEACHER, UserProfile.ROLE_STUDENT]:
        if role == UserProfile.ROLE_ADMIN:
            users = users.filter(Q(profile__role=UserProfile.ROLE_ADMIN) | Q(is_superuser=True))
        else:
            users = users.filter(profile__role=role)
    # 自定义排序：管理员 -> 教师 -> 学生 -> 其他
    users = users.annotate(
        role_rank=Case(
            When(Q(profile__role=UserProfile.ROLE_ADMIN) | Q(is_superuser=True), then=0),
            When(profile__role=UserProfile.ROLE_TEACHER, then=1),
            When(profile__role=UserProfile.ROLE_STUDENT, then=2),
            default=3,
            output_field=IntegerField(),
        )
    ).order_by('role_rank', '-date_joined')
    paginator = Paginator(users, 10)
    page = request.GET.get('page', 1)
    page_obj = paginator.get_page(page)

    # 操作：启用/禁用/角色调整
    if request.method == 'POST':
        action = request.POST.get('action')
        uid = request.POST.get('user_id')
        try:
            u = User.objects.get(id=uid)
        except User.DoesNotExist:
            return redirect('admin_users')
        if action == 'toggle_active':
            u.is_active = not u.is_active
            u.save()
        elif action == 'set_role':
            role = request.POST.get('role')
            profile = getattr(u, 'profile', None)
            if profile is None:
                profile = UserProfile.objects.create(user=u)
            if role in [UserProfile.ROLE_STUDENT, UserProfile.ROLE_TEACHER, UserProfile.ROLE_ADMIN]:
                profile.role = role
                profile.save()
        return redirect('admin_users')

    return render(request, 'myapp/admin_users.html', {
        'page_obj': page_obj,
        'q': q,
        'role': role,
    })


@_admin_required
def admin_courses(request):
    profile = getattr(request.user, 'profile', None)
    is_teacher = profile and profile.role == UserProfile.ROLE_TEACHER

    q = request.GET.get('q', '').strip()
    status = request.GET.get('status', '').strip()
    filter_my = request.GET.get('filter_my', '')

    courses = Course.objects.all().order_by('-created_at')
    
    if is_teacher or filter_my == '1':
        courses = courses.filter(created_by=request.user)
        
    if q:
        courses = courses.filter(Q(title__icontains=q) | Q(description__icontains=q))
    if status in [Course.STATUS_PUBLISHED, Course.STATUS_DRAFT, Course.STATUS_ARCHIVED]:
        courses = courses.filter(status=status)
    paginator = Paginator(courses, 10)
    page_obj = paginator.get_page(request.GET.get('page', 1))

    # 操作：上/下架、删除
    if request.method == 'POST':
        action = request.POST.get('action')
        cid = request.POST.get('course_id')
        try:
            c = Course.objects.get(id=cid)
            # 权限检查
            if is_teacher and c.created_by != request.user:
                return HttpResponseForbidden('无权限')
        except Course.DoesNotExist:
            return redirect('admin_courses')
        if action == 'toggle':
            c.status = Course.STATUS_ARCHIVED if c.status == Course.STATUS_PUBLISHED else Course.STATUS_PUBLISHED
            c.save()
        elif action == 'delete':
            c.delete()
        return redirect('admin_courses')

    return render(request, 'myapp/admin_courses.html', {
        'page_obj': page_obj,
        'q': q,
        'status': status,
        'is_teacher': is_teacher,
    })


@_admin_required
def admin_videos(request):
    """管理课程中的视频课节"""
    profile = getattr(request.user, 'profile', None)
    is_teacher = profile and profile.role == UserProfile.ROLE_TEACHER

    course_id = request.GET.get('course')
    filter_my = request.GET.get('filter_my', '')
    
    # 改为查询 Lesson 模型，且类型为视频
    videos = Lesson.objects.filter(lesson_type=Lesson.TYPE_VIDEO).select_related('chapter', 'chapter__course').order_by('-created_at')
    
    if is_teacher or filter_my == '1':
        videos = videos.filter(chapter__course__created_by=request.user)

    if course_id and course_id.isdigit():
        videos = videos.filter(chapter__course_id=int(course_id))
        
    paginator = Paginator(videos, 10)
    page_obj = paginator.get_page(request.GET.get('page', 1))

    # 操作：发布/下架、删除
    if request.method == 'POST':
        action = request.POST.get('action')
        vid = request.POST.get('video_id')
        try:
            v = Lesson.objects.get(id=vid, lesson_type=Lesson.TYPE_VIDEO)
            # 权限检查
            if is_teacher and v.chapter.course.created_by != request.user:
                return HttpResponseForbidden('无权限')
        except Lesson.DoesNotExist:
            return redirect('admin_videos')
            
        if action == 'toggle':
            v.is_published = not v.is_published
            v.save()
        elif action == 'delete':
            v.delete()
        return redirect('admin_videos')

    # 获取筛选用的课程列表
    course_qs = Course.objects.all().order_by('-created_at')
    if is_teacher:
        course_qs = course_qs.filter(created_by=request.user)

    return render(request, 'myapp/admin_videos.html', {
        'page_obj': page_obj,
        'courses': course_qs[:100],
        'current_course': course_id,
        'is_teacher': is_teacher,
    })


@_admin_required
def admin_comments(request):
    profile = getattr(request.user, 'profile', None)
    is_teacher = profile and profile.role == UserProfile.ROLE_TEACHER

    status = request.GET.get('status', '')
    rating = request.GET.get('rating', '')
    sort = request.GET.get('sort', '-created_at')
    filter_my = request.GET.get('filter_my', '')
    
    comments = Comment.objects.select_related('course', 'user')
    
    if is_teacher or filter_my == '1':
        comments = comments.filter(course__created_by=request.user)
    
    # 默认不显示待审核
    comments = comments.exclude(status=Comment.STATUS_PENDING)
    
    # 筛选状态
    if status in [Comment.STATUS_APPROVED, Comment.STATUS_REJECTED]:
        comments = comments.filter(status=status)
        
    # 筛选评分
    if rating and rating.isdigit():
        comments = comments.filter(rating=int(rating))
        
    # 排序
    if sort == 'rating_desc':
        comments = comments.order_by('-rating', '-created_at')
    elif sort == 'rating_asc':
        comments = comments.order_by('rating', '-created_at')
    else:
        comments = comments.order_by('-created_at')
        
    paginator = Paginator(comments, 10)
    page_obj = paginator.get_page(request.GET.get('page', 1))

    # 审核操作
    if request.method == 'POST':
        action = request.POST.get('action')
        cid = request.POST.get('comment_id')
        try:
            c = Comment.objects.get(id=cid)
        except Comment.DoesNotExist:
            return redirect('admin_comments')
        if action == 'approve':
            c.status = Comment.STATUS_APPROVED
            c.reject_reason = ''
            c.save()
        elif action == 'reject':
            c.status = Comment.STATUS_REJECTED
            c.reject_reason = request.POST.get('reason', '')[:255]
            c.save()
        elif action == 'delete':
            c.delete()
        return redirect('admin_comments')

    return render(request, 'myapp/admin_comments.html', {
        'page_obj': page_obj,
        'status': status,
        'rating': rating,
        'sort': sort,
    })


@_admin_required
def admin_banners(request):
    """轮播图管理"""
    profile = getattr(request.user, 'profile', None)
    if profile.role != UserProfile.ROLE_ADMIN:
        return HttpResponseForbidden('仅管理员可访问')

    banners = Banner.objects.all()
    
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'add':
            title = request.POST.get('title')
            image = request.FILES.get('image')
            if title and image:
                Banner.objects.create(
                    title=title,
                    image=image,
                    subtitle=request.POST.get('subtitle', ''),
                    url=request.POST.get('url', ''),
                    order=int(request.POST.get('order', 0)),
                    is_active=request.POST.get('is_active') == 'on'
                )
                messages.success(request, '轮播图已添加')
        elif action == 'edit':
            bid = request.POST.get('banner_id')
            b = Banner.objects.get(id=bid)
            b.title = request.POST.get('title')
            if 'image' in request.FILES:
                b.image = request.FILES['image']
            b.subtitle = request.POST.get('subtitle', '')
            b.url = request.POST.get('url', '')
            b.order = int(request.POST.get('order', 0))
            b.is_active = request.POST.get('is_active') == 'on'
            b.save()
            messages.success(request, '轮播图已更新')
        elif action == 'delete':
            bid = request.POST.get('banner_id')
            Banner.objects.filter(id=bid).delete()
            messages.success(request, '轮播图已删除')
        return redirect('admin_banners')

    return render(request, 'myapp/admin_banners.html', {'banners': banners})


@_admin_required
def admin_announcements(request):
    """公告管理"""
    profile = getattr(request.user, 'profile', None)
    if profile.role != UserProfile.ROLE_ADMIN:
        return HttpResponseForbidden('仅管理员可访问')

    announcements = Announcement.objects.all()
    
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'add':
            title = request.POST.get('title')
            content = request.POST.get('content')
            if title and content:
                Announcement.objects.create(
                    title=title,
                    content=content,
                    type=request.POST.get('type', 'info'),
                    is_active=request.POST.get('is_active') == 'on'
                )
                messages.success(request, '公告已发布')
        elif action == 'edit':
            aid = request.POST.get('announcement_id')
            a = Announcement.objects.get(id=aid)
            a.title = request.POST.get('title')
            a.content = request.POST.get('content')
            a.type = request.POST.get('type')
            a.is_active = request.POST.get('is_active') == 'on'
            a.save()
            messages.success(request, '公告已更新')
        elif action == 'delete':
            aid = request.POST.get('announcement_id')
            Announcement.objects.filter(id=aid).delete()
            messages.success(request, '公告已删除')
        return redirect('admin_announcements')

    return render(request, 'myapp/admin_announcements.html', {
        'announcements': announcements,
        'type_choices': Announcement.TYPE_CHOICES
    })


@_admin_required
def admin_refunds(request):
    """退款申请管理（后台）"""
    profile = getattr(request.user, 'profile', None)
    if not profile or profile.role not in [UserProfile.ROLE_ADMIN, UserProfile.ROLE_TEACHER]:
        return HttpResponseForbidden('仅管理员或教师可访问')

    refunds = RefundApplication.objects.select_related('user', 'purchase__course').order_by('-created_at')
    
    # 如果是教师，只看自己课程的退款申请
    if profile.role == UserProfile.ROLE_TEACHER:
        refunds = refunds.filter(purchase__course__created_by=request.user)

    if request.method == 'POST':
        action = request.POST.get('action')
        aid = request.POST.get('application_id')
        remark = request.POST.get('remark', '')

        try:
            application = RefundApplication.objects.get(id=aid)
            # 权限校验
            if profile.role == UserProfile.ROLE_TEACHER and application.purchase.course.created_by != request.user:
                return HttpResponseForbidden('无权限处理此申请')

            if action == 'approve':
                if application.status == RefundApplication.STATUS_PENDING:
                    # 更新申请状态
                    application.status = RefundApplication.STATUS_APPROVED
                    application.admin_remark = remark
                    application.save()

                    # 更新订单状态
                    purchase = application.purchase
                    purchase.status = CoursePurchase.STATUS_REFUNDED
                    purchase.save()

                    # 取消选课状态（退课逻辑）
                    CourseEnrollment.objects.filter(student=purchase.user, course=purchase.course).update(is_active=False)
                    
                    messages.success(request, f'退款申请 {application.application_no} 已同意并完成退课')
            
            elif action == 'reject':
                if application.status == RefundApplication.STATUS_PENDING:
                    application.status = RefundApplication.STATUS_REJECTED
                    application.admin_remark = remark
                    application.save()
                    messages.success(request, f'退款申请 {application.application_no} 已驳回')

        except RefundApplication.DoesNotExist:
            messages.error(request, '申请不存在')

        return redirect('admin_refunds')

    return render(request, 'myapp/admin_refunds.html', {
        'refunds': refunds
    })


def video_player(request, course_id):
    """视频播放页面"""
    try:
        course = Course.objects.get(id=course_id, status=Course.STATUS_PUBLISHED)
    except Course.DoesNotExist:
        return HttpResponseForbidden('课程不存在或未发布')
    
    # 访问控制：未公开的课程需要已购买才可播放（管理员和教师除外）
    if not course.is_public and course.price > 0:
        if not request.user.is_authenticated:
            return force_login(request)
        
        # 检查用户角色：管理员和教师无需购买
        user_profile = getattr(request.user, 'profile', None)
        is_admin_or_teacher = (user_profile and user_profile.role in [UserProfile.ROLE_ADMIN, UserProfile.ROLE_TEACHER]) or request.user.is_superuser
        
        if not is_admin_or_teacher and not CoursePurchase.objects.filter(user=request.user, course=course, status=CoursePurchase.STATUS_PAID).exists():
            messages.warning(request, '此课程为付费课程，请购买后观看。')
            return redirect('course_detail', course_id=course.id)

    # 获取用户对当前课程的点赞和收藏状态
    user_liked = False
    user_favorited = False
    if request.user.is_authenticated:
        user_liked = VideoLike.objects.filter(user=request.user, course=course).exists()
        user_favorited = VideoFavorite.objects.filter(user=request.user, course=course).exists()
    
    # 获取统计数据
    like_count = VideoLike.objects.filter(course=course).count()
    favorite_count = VideoFavorite.objects.filter(course=course).count()
    
    # 获取所有评论（不再需要审核）
    comments = Comment.objects.filter(course=course).order_by('-created_at')[:10]
    
    # 章节/课节目录与当前课节
    chapters = Chapter.objects.filter(course=course).prefetch_related('lessons')
    current_lesson = None
    
    # 推荐课程逻辑：同专业领域优先，其次按点赞数排序
    recommended_courses = Course.objects.filter(
        status=Course.STATUS_PUBLISHED
    ).exclude(id=course.id)
    
    if course.major:
        major_courses = list(recommended_courses.filter(major=course.major).annotate(likes_count=Count('likes')).order_by('-likes_count')[:3])
        if len(major_courses) < 3:
            major_ids = [c.id for c in major_courses]
            other_courses = list(recommended_courses.exclude(id__in=major_ids).annotate(likes_count=Count('likes')).order_by('-likes_count')[:3 - len(major_courses)])
            recommended_courses = major_courses + other_courses
        else:
            recommended_courses = major_courses
    else:
        recommended_courses = list(recommended_courses.annotate(likes_count=Count('likes')).order_by('-likes_count')[:3])

    lesson_id = request.GET.get('lesson')
    if lesson_id and lesson_id.isdigit():
        current_lesson = Lesson.objects.filter(id=int(lesson_id), chapter__course=course).first()
    
    if current_lesson is None:
        # 选择第一个有课节的章节的第一节
        first_chapter = chapters.first()
        if first_chapter:
            current_lesson = first_chapter.lessons.first()

    # 决定播放内容（课节优先，其次课程级别视频/外链）
    embed_url = None
    if current_lesson and current_lesson.lesson_type == Lesson.TYPE_VIDEO and current_lesson.video_url:
        embed_url = current_lesson.video_url
    elif course.video_url:
        embed_url = course.video_url
    
    # 将部分外链转换为可嵌入
    if embed_url:
        try:
            # 支持 Bilibili iframe 嵌入代码提取
            import re
            bilibili_iframe_pattern = re.search(r'src="(//player\.bilibili\.com/player\.html\?bvid=[^"]+)"', embed_url)
            if bilibili_iframe_pattern:
                embed_url = "https:" + bilibili_iframe_pattern.group(1)
            elif 'youtube.com/watch' in embed_url:
                if 'v=' in embed_url:
                    video_id = embed_url.split('v=')[1].split('&')[0]
                    embed_url = f'https://www.youtube.com/embed/{video_id}'
            elif 'youtu.be/' in embed_url:
                video_id = embed_url.split('youtu.be/')[1].split('?')[0]
                embed_url = f'https://www.youtube.com/embed/{video_id}'
            elif 'bilibili.com/video/' in embed_url and 'BV' in embed_url:
                bv_id = embed_url.split('BV')[1].split('/')[0]
                embed_url = f'https://player.bilibili.com/player.html?bvid=BV{bv_id}'
        except Exception as e:
            # 防止解析错误导致 500
            print(f"Error parsing embed_url: {e}")
            pass

    # 获取当前课节的学习进度
    lesson_completed = False
    current_time = 0
    if request.user.is_authenticated and current_lesson:
        try:
            progress = LessonProgress.objects.get(
                user=request.user, 
                lesson=current_lesson
            )
            lesson_completed = progress.is_completed
            current_time = progress.current_time
        except LessonProgress.DoesNotExist:
            pass

    return render(request, 'myapp/video_player.html', {
        'course': course,
        'user_liked': user_liked,
        'user_favorited': user_favorited,
        'like_count': like_count,
        'favorite_count': favorite_count,
        'comments': comments,
        'user_authenticated': request.user.is_authenticated,
        'embed_url': embed_url,
        'chapters': chapters,
        'current_lesson': current_lesson,
        'lesson_completed': lesson_completed,
        'recommended_courses': recommended_courses,
        'current_time': current_time,
    })


def purchase_course(request, course_id):
    """购买课程（示例：直接标记为已购买，不集成真实支付网关）"""
    if not request.user.is_authenticated:
        return force_login(request)
    try:
        course = Course.objects.get(id=course_id, status=Course.STATUS_PUBLISHED)
    except Course.DoesNotExist:
        return HttpResponseForbidden('课程不存在或未发布')

    # 检查用户角色：管理员和教师无需购买
    user_profile = getattr(request.user, 'profile', None)
    if user_profile and user_profile.role in [UserProfile.ROLE_ADMIN, UserProfile.ROLE_TEACHER]:
        messages.info(request, '管理员和教师可以免费访问所有课程。')
        return redirect('course_detail', course_id=course.id)
    
    # 超级用户也无需购买
    if request.user.is_superuser:
        messages.info(request, '超级用户可以免费访问所有课程。')
        return redirect('course_detail', course_id=course.id)

    # 公开课或免费课程无需购买
    if course.is_public or course.price == 0:
        messages.info(request, '该课程无需购买。')
        return redirect('course_detail', course_id=course.id)

    # 检查是否已购买
    if CoursePurchase.objects.filter(user=request.user, course=course, status=CoursePurchase.STATUS_PAID).exists():
        messages.info(request, '您已购买过该课程。')
        return redirect('course_detail', course_id=course.id)

    # GET请求显示确认页面
    if request.method == 'GET':
        return render(request, 'myapp/purchase_confirm.html', {
            'course': course,
        })
    
    # POST请求处理购买
    if request.method == 'POST':
        # 创建购买记录（幂等）
        purchase, created = CoursePurchase.objects.get_or_create(
            user=request.user,
            course=course,
            defaults={
                'amount': course.price,
                'status': CoursePurchase.STATUS_PAID
            }
        )
        if created:
            # 购买成功后自动选课
            CourseEnrollment.objects.update_or_create(
                student=request.user, 
                course=course, 
                defaults={'is_active': True}
            )
            messages.success(request, '购买成功，已为您开通课程访问权限。')
        else:
            if purchase.status != CoursePurchase.STATUS_PAID:
                 purchase.status = CoursePurchase.STATUS_PAID
                 purchase.save()
                 messages.success(request, '购买成功，已为您开通课程访问权限。')
                 CourseEnrollment.objects.update_or_create(
                     student=request.user, 
                     course=course, 
                     defaults={'is_active': True}
                 )
            else:
                 messages.info(request, '您已购买过该课程。')
        return redirect('course_detail', course_id=course.id)

def my_orders(request):
    """我的订单"""
    if not request.user.is_authenticated:
        return force_login(request)
    
    orders = CoursePurchase.objects.filter(user=request.user).select_related('course', 'refund_application').order_by('-paid_at')
    
    paginator = Paginator(orders, 10)
    page_obj = paginator.get_page(request.GET.get('page', 1))
    
    return render(request, 'myapp/my_orders.html', {
        'page_obj': page_obj
    })


def apply_refund(request, order_no):
    """申请退款视图"""
    if not request.user.is_authenticated:
        return force_login(request)
    
    try:
        purchase = CoursePurchase.objects.get(order_no=order_no, user=request.user)
    except CoursePurchase.DoesNotExist:
        messages.error(request, '订单不存在')
        return redirect('my_orders')

    # 检查是否已经申请过退款
    if hasattr(purchase, 'refund_application'):
        messages.warning(request, '该订单已提交过退款申请')
        return redirect('my_orders')

    # 获取学习进度
    enrollment = CourseEnrollment.objects.filter(student=request.user, course=purchase.course).first()
    progress = enrollment.progress_percentage if enrollment else 0

    # 计算预计退款金额
    # 政策：0%进度退100%，<20%退80%，<50%退50%，>=50%不予退款
    if progress == 0:
        refund_ratio = 1.0
    elif progress < 20:
        refund_ratio = 0.8
    elif progress < 50:
        refund_ratio = 0.5
    else:
        refund_ratio = 0.0

    refund_amount = float(purchase.amount) * refund_ratio

    if request.method == 'POST':
        reason = request.POST.get('reason')
        custom_reason = request.POST.get('custom_reason', '').strip()
        description = request.POST.get('description', '')
        contact_info = request.POST.get('contact_info', '')

        if reason == 'other' and custom_reason:
            reason_to_save = custom_reason
        else:
            reason_to_save = reason

        if not reason:
            messages.error(request, '请选择退款原因')
        elif reason == 'other' and not custom_reason:
            messages.error(request, '请填写自定义退款原因')
        elif not contact_info:
            messages.error(request, '请填写联系方式')
        elif refund_ratio == 0:
            messages.error(request, '课程学习进度已超过50%，不符合退款政策')
        else:
            application = RefundApplication.objects.create(
                purchase=purchase,
                user=request.user,
                reason=reason_to_save[:100],  # 截断以适应字段长度
                description=description,
                contact_info=contact_info,
                refund_amount=refund_amount,
                progress_at_refund=progress
            )
            # 发送模拟通知
            messages.success(request, f'退款申请已提交！申请单号：{application.application_no}。请耐心等待管理员审核。')
            return redirect('my_orders')

    return render(request, 'myapp/refund_apply.html', {
        'purchase': purchase,
        'progress': progress,
        'refund_amount': refund_amount,
        'refund_ratio': int(refund_ratio * 100),
        'reasons': RefundApplication.REASON_CHOICES
    })


def download_course_resource(request, course_id, resource_id):
    """受保护的课程资源下载：未购买的付费课程禁止下载"""
    try:
        course = Course.objects.get(id=course_id)
        resource = CourseResource.objects.get(id=resource_id, course=course)
    except (Course.DoesNotExist, CourseResource.DoesNotExist):
        return HttpResponseForbidden('资源不存在')

    # 若为付费且未公开，需检查购买（管理员和教师除外）
    if not course.is_public and course.price > 0:
        if not request.user.is_authenticated:
            return force_login(request)
        
        # 检查用户角色：管理员和教师无需购买
        user_profile = getattr(request.user, 'profile', None)
        is_admin_or_teacher = (user_profile and user_profile.role in [UserProfile.ROLE_ADMIN, UserProfile.ROLE_TEACHER]) or request.user.is_superuser
        
        if not is_admin_or_teacher and not CoursePurchase.objects.filter(user=request.user, course=course, status=CoursePurchase.STATUS_PAID).exists():
            return HttpResponseForbidden('未购买该课程，无法下载资源')

    # 允许下载：重定向到文件URL（简单实现）
    return redirect(resource.file.url)


def toggle_like(request, course_id):
    """切换点赞状态"""
    if not request.user.is_authenticated:
        return force_login(request)
    
    try:
        course = Course.objects.get(id=course_id, status=Course.STATUS_PUBLISHED)
    except Course.DoesNotExist:
        return HttpResponseForbidden('课程不存在')
    
    like, created = VideoLike.objects.get_or_create(user=request.user, course=course)
    if not created:
        like.delete()
    
    like_count = VideoLike.objects.filter(course=course).count()
    
    from django.http import JsonResponse
    return JsonResponse({
        'liked': created,
        'like_count': like_count
    })


def toggle_favorite(request, course_id):
    """切换收藏状态"""
    if not request.user.is_authenticated:
        return force_login(request)
    
    try:
        course = Course.objects.get(id=course_id, status=Course.STATUS_PUBLISHED)
    except Course.DoesNotExist:
        return HttpResponseForbidden('课程不存在')
    
    favorite, created = VideoFavorite.objects.get_or_create(user=request.user, course=course)
    if not created:
        favorite.delete()
    
    favorite_count = VideoFavorite.objects.filter(course=course).count()
    
    from django.http import JsonResponse
    return JsonResponse({
        'favorited': created,
        'favorite_count': favorite_count
    })


def add_comment(request, course_id):
    """添加评论"""
    if not request.user.is_authenticated:
        return force_login(request)
    
    try:
        course = Course.objects.get(id=course_id, status=Course.STATUS_PUBLISHED)
    except Course.DoesNotExist:
        return HttpResponseForbidden('课程不存在')
    
    if request.method == 'POST':
        content = request.POST.get('content', '').strip()
        rating = int(request.POST.get('rating', 5))
        
        if content:
            Comment.objects.create(
                course=course,
                user=request.user,
                content=content,
                rating=rating,
                status=Comment.STATUS_APPROVED  # 直接设为已通过状态
            )
    
    return redirect('video_player', course_id=course_id)


def password_reset_simple(request):
    """基于手机号+邮箱直接重置密码（无需邮件链接）。"""
    if request.method == 'POST':
        email = request.POST.get('email', '').strip()
        phone = request.POST.get('phone', '').strip()
        new_password1 = request.POST.get('new_password1', '').strip()
        new_password2 = request.POST.get('new_password2', '').strip()

        # 基本校验
        if not email or not phone or not new_password1 or not new_password2:
            messages.error(request, '请完整填写所有字段。')
            return render(request, 'myapp/password_reset_simple.html')

        if new_password1 != new_password2:
            messages.error(request, '两次输入的新密码不一致。')
            return render(request, 'myapp/password_reset_simple.html', {
                'email': email,
                'phone': phone,
            })

        # 查找用户并校验邮箱+手机号
        user = User.objects.filter(email__iexact=email).first()
        if not user:
            messages.error(request, '未找到该邮箱对应的用户。')
            return render(request, 'myapp/password_reset_simple.html', {
                'email': email,
                'phone': phone,
            })

        profile = getattr(user, 'profile', None)
        if not profile or (profile.phone or '').strip() != phone:
            messages.error(request, '手机号与邮箱不匹配。')
            return render(request, 'myapp/password_reset_simple.html', {
                'email': email,
                'phone': phone,
            })

        # 设置新密码
        try:
            user.set_password(new_password1)
            user.save()
        except Exception:
            messages.error(request, '设置新密码失败，请稍后重试。')
            return render(request, 'myapp/password_reset_simple.html')

        messages.success(request, '密码已重置成功，请使用新密码登录。')
        return force_login(request)

    return render(request, 'myapp/password_reset_simple.html')

def my_favorites(request):
    """我的收藏页面"""
    if not request.user.is_authenticated:
        return force_login(request)
    
    # 获取用户收藏的课程
    favorites = VideoFavorite.objects.filter(user=request.user).select_related('course').order_by('-created_at')
    
    # 分页
    paginator = Paginator(favorites, 12)
    page = request.GET.get('page', 1)
    page_obj = paginator.get_page(page)
    
    return render(request, 'myapp/my_favorites.html', {
        'page_obj': page_obj,
        'total_favorites': favorites.count(),
    })


def teacher_detail(request, username):
    """讲师详情：简介与其创建的课程列表"""
    try:
        user = User.objects.get(username=username)
        # 验证是否为教师或管理员
        profile = getattr(user, 'profile', None)
        is_teacher_or_admin = user.is_superuser or (profile and profile.role in [UserProfile.ROLE_TEACHER, UserProfile.ROLE_ADMIN])
        if not is_teacher_or_admin:
             return HttpResponseForbidden('该用户不是讲师')
    except User.DoesNotExist:
        return HttpResponseForbidden('讲师不存在')
    
    courses = Course.objects.filter(created_by=user).order_by('-created_at')
    paginator = Paginator(courses, 12)
    page_obj = paginator.get_page(request.GET.get('page', 1))
    return render(request, 'myapp/teacher_detail.html', {
        'teacher': user,
        'profile': profile,
        'page_obj': page_obj,
    })


# ==================== 作业管理相关视图 ====================

@role_required([UserProfile.ROLE_TEACHER, UserProfile.ROLE_ADMIN])
def assignment_list(request, course_id):
    """课程作业列表（教师）"""
    try:
        profile = getattr(request.user, 'profile', None)
        is_admin = (profile and profile.role == UserProfile.ROLE_ADMIN) or request.user.is_superuser
        course = Course.objects.get(id=course_id) if is_admin else Course.objects.get(id=course_id, created_by=request.user)
    except Course.DoesNotExist:
        return HttpResponseForbidden('课程不存在或无权限')
    
    assignments = Assignment.objects.filter(course=course).order_by('-created_at')
    
    return render(request, 'myapp/assignment_list.html', {
        'course': course,
        'assignments': assignments,
    })


@role_required([UserProfile.ROLE_TEACHER, UserProfile.ROLE_ADMIN])
def assignment_create(request, course_id):
    """创建作业（教师）"""
    try:
        profile = getattr(request.user, 'profile', None)
        is_admin = (profile and profile.role == UserProfile.ROLE_ADMIN) or request.user.is_superuser
        course = Course.objects.get(id=course_id) if is_admin else Course.objects.get(id=course_id, created_by=request.user)
    except Course.DoesNotExist:
        return HttpResponseForbidden('课程不存在或无权限')
    
    if request.method == 'POST':
        form = AssignmentForm(request.POST)
        if form.is_valid():
            assignment = form.save(commit=False)
            assignment.course = course
            assignment.created_by = request.user
            assignment.save()
            messages.success(request, '作业创建成功！')
            return redirect('assignment_list', course_id=course.id)
    else:
        form = AssignmentForm()
    
    return render(request, 'myapp/assignment_create.html', {
        'course': course,
        'form': form,
    })


@role_required([UserProfile.ROLE_TEACHER, UserProfile.ROLE_ADMIN])
def assignment_edit(request, course_id, assignment_id):
    """编辑作业（教师）"""
    try:
        profile = getattr(request.user, 'profile', None)
        is_admin = (profile and profile.role == UserProfile.ROLE_ADMIN) or request.user.is_superuser
        course = Course.objects.get(id=course_id) if is_admin else Course.objects.get(id=course_id, created_by=request.user)
        assignment = Assignment.objects.get(id=assignment_id, course=course)
    except (Course.DoesNotExist, Assignment.DoesNotExist):
        return HttpResponseForbidden('作业不存在或无权限')
    
    if request.method == 'POST':
        form = AssignmentForm(request.POST, instance=assignment)
        if form.is_valid():
            form.save()
            messages.success(request, '作业更新成功！')
            return redirect('assignment_list', course_id=course.id)
    else:
        form = AssignmentForm(instance=assignment)
    
    return render(request, 'myapp/assignment_edit.html', {
        'course': course,
        'assignment': assignment,
        'form': form,
    })


@role_required([UserProfile.ROLE_TEACHER, UserProfile.ROLE_ADMIN])
def assignment_delete(request, course_id, assignment_id):
    """删除作业（教师）"""
    try:
        profile = getattr(request.user, 'profile', None)
        is_admin = (profile and profile.role == UserProfile.ROLE_ADMIN) or request.user.is_superuser
        course = Course.objects.get(id=course_id) if is_admin else Course.objects.get(id=course_id, created_by=request.user)
        assignment = Assignment.objects.get(id=assignment_id, course=course)
    except (Course.DoesNotExist, Assignment.DoesNotExist):
        return HttpResponseForbidden('作业不存在或无权限')
    
    if request.method == 'POST':
        assignment.delete()
        messages.success(request, '作业删除成功！')
        return redirect('assignment_list', course_id=course.id)
    
    return render(request, 'myapp/assignment_delete.html', {
        'course': course,
        'assignment': assignment,
    })


@role_required([UserProfile.ROLE_TEACHER, UserProfile.ROLE_ADMIN])
def assignment_submissions(request, course_id, assignment_id):
    """查看作业提交（教师）"""
    try:
        profile = getattr(request.user, 'profile', None)
        is_admin = (profile and profile.role == UserProfile.ROLE_ADMIN) or request.user.is_superuser
        course = Course.objects.get(id=course_id) if is_admin else Course.objects.get(id=course_id, created_by=request.user)
        assignment = Assignment.objects.get(id=assignment_id, course=course)
    except (Course.DoesNotExist, Assignment.DoesNotExist):
        return HttpResponseForbidden('作业不存在或无权限')
    
    submissions = AssignmentSubmission.objects.filter(assignment=assignment).select_related('student', 'student__profile').order_by('-submitted_at')
    
    return render(request, 'myapp/assignment_submissions.html', {
        'course': course,
        'assignment': assignment,
        'submissions': submissions,
    })


@role_required([UserProfile.ROLE_TEACHER, UserProfile.ROLE_ADMIN])
def assignment_grade(request, course_id, assignment_id, submission_id):
    """批改作业（教师）"""
    try:
        profile = getattr(request.user, 'profile', None)
        is_admin = (profile and profile.role == UserProfile.ROLE_ADMIN) or request.user.is_superuser
        course = Course.objects.get(id=course_id) if is_admin else Course.objects.get(id=course_id, created_by=request.user)
        assignment = Assignment.objects.get(id=assignment_id, course=course)
        submission = AssignmentSubmission.objects.get(id=submission_id, assignment=assignment)
    except (Course.DoesNotExist, Assignment.DoesNotExist, AssignmentSubmission.DoesNotExist):
        return HttpResponseForbidden('提交不存在或无权限')
    
    # 获取或创建成绩记录
    grade, created = AssignmentGrade.objects.get_or_create(
        submission=submission,
        defaults={'grader': request.user, 'score': 0}
    )
    
    if request.method == 'POST':
        form = AssignmentGradeForm(request.POST, instance=grade, assignment=assignment)
        if form.is_valid():
            form.save()
            messages.success(request, '批改完成！')
            return redirect('assignment_submissions', course_id=course.id, assignment_id=assignment.id)
    else:
        form = AssignmentGradeForm(instance=grade, assignment=assignment)
    
    return render(request, 'myapp/assignment_grade.html', {
        'course': course,
        'assignment': assignment,
        'submission': submission,
        'grade': grade,
        'form': form,
    })


def student_assignments(request):
    """学生作业列表"""
    if not request.user.is_authenticated:
        return force_login(request)
    
    # 获取学生已选的课程
    enrolled_courses = Course.objects.filter(
        enrollments__student=request.user,
        enrollments__is_active=True
    ).distinct()
    
    # 获取这些课程的已发布作业
    assignments = Assignment.objects.filter(
        course__in=enrolled_courses,
        is_published=True
    ).select_related('course', 'created_by').order_by('-due_date')
    
    # 获取学生的提交记录
    submissions = AssignmentSubmission.objects.filter(
        student=request.user,
        assignment__in=assignments
    ).select_related('assignment')
    
    submission_dict = {sub.assignment.id: sub for sub in submissions}
    
    return render(request, 'myapp/student_assignments.html', {
        'assignments': assignments,
        'submission_dict': submission_dict,
        'enrolled_courses': enrolled_courses,
    })


def assignment_detail(request, course_id, assignment_id):
    """作业详情页面"""
    try:
        course = Course.objects.get(id=course_id)
        assignment = Assignment.objects.get(id=assignment_id, course=course, is_published=True)
    except (Course.DoesNotExist, Assignment.DoesNotExist):
        return HttpResponseForbidden('作业不存在')
    
    # 检查学生是否已选课
    if request.user.is_authenticated and request.user.profile.role == 'student':
        try:
            CourseEnrollment.objects.get(
                student=request.user,
                course=course,
                is_active=True
            )
        except CourseEnrollment.DoesNotExist:
            return HttpResponseForbidden('您需要先选择此课程才能查看作业')
    
    # 检查学生是否已提交
    submission = None
    grade = None
    if request.user.is_authenticated:
        try:
            submission = AssignmentSubmission.objects.get(assignment=assignment, student=request.user)
            grade = getattr(submission, 'grade', None)
        except AssignmentSubmission.DoesNotExist:
            pass
    
    return render(request, 'myapp/assignment_detail.html', {
        'course': course,
        'assignment': assignment,
        'submission': submission,
        'grade': grade,
    })


def assignment_submit(request, course_id, assignment_id):
    """提交作业（学生）"""
    if not request.user.is_authenticated:
        return force_login(request)
    
    try:
        course = Course.objects.get(id=course_id)
        assignment = Assignment.objects.get(id=assignment_id, course=course, is_published=True)
    except (Course.DoesNotExist, Assignment.DoesNotExist):
        return HttpResponseForbidden('作业不存在')
    
    # 检查学生是否已选课
    try:
        CourseEnrollment.objects.get(
            student=request.user,
            course=course,
            is_active=True
        )
    except CourseEnrollment.DoesNotExist:
        return HttpResponseForbidden('您需要先选择此课程才能提交作业')
    
    # 检查是否已提交
    try:
        submission = AssignmentSubmission.objects.get(assignment=assignment, student=request.user)
        messages.info(request, '您已经提交过此作业，可以重新提交覆盖。')
    except AssignmentSubmission.DoesNotExist:
        submission = None
    
    if request.method == 'POST':
        form = AssignmentSubmissionForm(request.POST, request.FILES, instance=submission)
        if form.is_valid():
            submission = form.save(commit=False)
            submission.assignment = assignment
            submission.student = request.user
            submission.save()
            messages.success(request, '作业提交成功！')
            return redirect('assignment_detail', course_id=course.id, assignment_id=assignment.id)
    else:
        form = AssignmentSubmissionForm(instance=submission)
    
    return render(request, 'myapp/assignment_submit.html', {
        'course': course,
        'assignment': assignment,
        'form': form,
        'submission': submission,
    })


# ==================== 选课管理相关视图 ====================

def enroll_course(request, course_id):
    """学生选课"""
    if not request.user.is_authenticated:
        return force_login(request)
    
    # 仅允许已发布课程
    try:
        course = Course.objects.get(id=course_id, status=Course.STATUS_PUBLISHED)
    except Course.DoesNotExist:
        messages.error(request, '课程不存在或未发布')
        return redirect('course_learn')

    # 非公开或付费课程：未购买则提示购买；已购买允许选课
    # 修正逻辑：只要是付费课程 (price > 0)，无论是否公开，选课前都必须检查购买状态
    if course.price > 0:
        has_purchased = CoursePurchase.objects.filter(user=request.user, course=course, status=CoursePurchase.STATUS_PAID).exists()
        if not has_purchased:
            messages.warning(request, '该课程为付费课程，请购买后再选课。')
            from django.http import HttpResponseRedirect
            return HttpResponseRedirect(f"/courses/{course.id}/?showBuy=1")
    
    # 检查是否已经选过这门课
    enrollment, created = CourseEnrollment.objects.get_or_create(
        student=request.user,
        course=course,
        defaults={'is_active': True}
    )
    
    if created:
        messages.success(request, f'成功选择课程《{course.title}》！')
    else:
        if enrollment.is_active:
            messages.info(request, f'您已经选择了课程《{course.title}》')
        else:
            enrollment.is_active = True
            enrollment.save()
            messages.success(request, f'重新激活课程《{course.title}》！')
    
    return redirect('course_detail', course_id=course.id)


def unenroll_course(request, course_id):
    """学生退课"""
    if not request.user.is_authenticated:
        return force_login(request)
    
    try:
        course = Course.objects.get(id=course_id)
        enrollment = CourseEnrollment.objects.get(student=request.user, course=course)
    except (Course.DoesNotExist, CourseEnrollment.DoesNotExist):
        return HttpResponseForbidden('选课记录不存在')
    
    if request.method == 'POST':
        enrollment.is_active = False
        enrollment.save()
        
        # 记录退课日志
        from .models import UnenrollLog
        ip = request.META.get('REMOTE_ADDR')
        UnenrollLog.objects.create(user=request.user, course=course, ip_address=ip)

        # 无论是否付费，仅停用选课，不产生退款流程，不删除购买记录
        # 这样用户以后可以随时重新加入而无需再次付费
        messages.success(request, f'已退出课程《{course.title}》。您已购买本课程，退课后可随时重新加入，无需再次付费。')
        return redirect('my_courses')
    
    return render(request, 'myapp/unenroll_course.html', {
        'course': course,
        'enrollment': enrollment,
    })


def my_courses(request):
    """我的课程列表（学生）"""
    if not request.user.is_authenticated:
        return force_login(request)
    
    # 获取学生已选的课程 (必须是已激活且付费课程需已支付)
    enrollments = CourseEnrollment.objects.filter(
        student=request.user,
        is_active=True
    ).select_related('course', 'course__created_by').order_by('-enrolled_at')
    
    # 额外过滤：如果课程是付费的，必须有成功的购买记录
    active_enrollments = []
    for enrollment in enrollments:
        if enrollment.course.price > 0:
            has_paid = CoursePurchase.objects.filter(
                user=request.user, 
                course=enrollment.course, 
                status=CoursePurchase.STATUS_PAID
            ).exists()
            if not has_paid:
                # 理论上不应该出现这种情况，但为了鲁棒性，如果未支付则设为不活跃
                enrollment.is_active = False
                enrollment.save()
                continue
        active_enrollments.append(enrollment)
    
    enrollments = active_enrollments

    # 为每个选课记录附加学习进度信息
    for enrollment in enrollments:
        course = enrollment.course
        
        # 1. 计算总进度
        total_lessons = Lesson.objects.filter(chapter__course=course).count()
        completed_lessons = LessonProgress.objects.filter(
            user=request.user, 
            lesson__chapter__course=course, 
            is_completed=True
        ).count()
        
        if total_lessons > 0:
            enrollment.progress_percent = int((completed_lessons / total_lessons) * 100)
        else:
            enrollment.progress_percent = 0
            
        # 2. 获取最近学习的课节
        last_progress = LessonProgress.objects.filter(
            user=request.user, 
            lesson__chapter__course=course
        ).order_by('-updated_at').first()
        
        if last_progress:
            enrollment.last_lesson = last_progress.lesson
            enrollment.last_studied_at = last_progress.updated_at
        else:
            enrollment.last_lesson = None
            enrollment.last_studied_at = None
    
    return render(request, 'myapp/my_courses.html', {
        'enrollments': enrollments,
    })


@require_POST
def upload_image(request):
    """TinyMCE 图片上传处理"""
    if not request.user.is_authenticated:
        return JsonResponse({'error': '未登录'}, status=403)
    
    # 仅允许教师或管理员上传
    profile = getattr(request.user, 'profile', None)
    if not request.user.is_superuser and (not profile or profile.role not in [UserProfile.ROLE_TEACHER, UserProfile.ROLE_ADMIN]):
        return JsonResponse({'error': '无权限上传图片'}, status=403)

    if 'file' in request.FILES:
        image_file = request.FILES['file']
        
        # 简单校验文件类型
        if not image_file.name.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp')):
            return JsonResponse({'error': '不支持的文件类型'}, status=400)
        
        # 保存图片到临时目录或专门的富文本图片目录
        import os
        from django.conf import settings
        from django.core.files.storage import default_storage
        from django.core.files.base import ContentFile
        import uuid

        ext = os.path.splitext(image_file.name)[1]
        filename = f"tinymce/{uuid.uuid4()}{ext}"
        path = default_storage.save(filename, ContentFile(image_file.read()))
        
        file_url = settings.MEDIA_URL + path
        return JsonResponse({'location': file_url})
    
    return JsonResponse({'error': '未找到上传的文件'}, status=400)

def test_tinymce(request):
    return render(request, 'test_tinymce.html')

def edit_lesson_content(request, lesson_id):
    """独立的图文课内容编辑器视图"""
    lesson = get_object_or_404(Lesson, id=lesson_id)
    course = lesson.chapter.course
    
    # 权限检查：必须是课程所有者或管理员
    if not request.user.is_authenticated:
        return force_login(request)
        
    profile = getattr(request.user, 'profile', None)
    is_admin = request.user.is_superuser or (profile and profile.role == UserProfile.ROLE_ADMIN)
    is_owner = (course.created_by == request.user)
    
    if not (is_admin or is_owner):
        return HttpResponseForbidden("您没有权限编辑此课程内容")
        
    if request.method == 'POST':
        content = request.POST.get('content', '')
        lesson.text_content = content
        lesson.save()
        messages.success(request, '课节内容已保存')
        return redirect('edit_lesson_content', lesson_id=lesson.id)
        
    return render(request, 'myapp/lesson_content_editor.html', {
        'lesson': lesson,
        'course': course
    })




@require_POST
def update_lesson_progress(request):
    """更新课节学习进度"""
    if not request.user.is_authenticated:
        return JsonResponse({'status': 'error', 'message': '未登录'}, status=403)
    
    # 尝试从 POST 或 JSON body 获取数据
    import json
    data = request.POST
    if request.body:
        try:
            json_data = json.loads(request.body)
            data = json_data
        except:
            pass

    lesson_id = data.get('lesson_id')
    
    # 兼容旧逻辑：手动切换完成状态
    is_completed_str = str(data.get('is_completed', '')).lower()
    manual_toggle = is_completed_str in ['true', 'false']
    
    # 新逻辑：自动进度更新
    current_time = data.get('current_time')
    duration = data.get('duration')
    
    try:
        lesson = Lesson.objects.get(id=lesson_id)
        progress, created = LessonProgress.objects.get_or_create(user=request.user, lesson=lesson)
        
        # 1. 手动标记完成
        if manual_toggle:
            progress.is_completed = is_completed_str == 'true'
            
        # 2. 自动进度更新
        elif current_time is not None:
            try:
                current_time = int(float(current_time))
                duration = int(float(duration or 0))
                
                progress.current_time = current_time
                if duration > 0:
                    progress.duration = duration
                
                # 更新最大观看进度
                if current_time > progress.max_watched_time:
                    progress.max_watched_time = current_time
                
                # 自动标记完成：观看超过 90%
                if duration > 0 and (progress.max_watched_time / duration) >= 0.9:
                    progress.is_completed = True
                    
            except ValueError:
                pass
        
        progress.save()
        return JsonResponse({
            'status': 'success', 
            'is_completed': progress.is_completed,
            'max_watched_time': progress.max_watched_time
        })
        
    except Lesson.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': '课节不存在'}, status=404)