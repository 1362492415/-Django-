"""
URL configuration for myproject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from myapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('myapp.urls')),
    path('admin-dashboard/users/', views.admin_users, name='admin_users'),
    path('admin-dashboard/courses/', views.admin_courses, name='admin_courses'),
    path('admin-dashboard/comments/', views.admin_comments, name='admin_comments'),
    path('admin-dashboard/banners/', views.admin_banners, name='admin_banners'),
    path('admin-dashboard/announcements/', views.admin_announcements, name='admin_announcements'),
    # path('admin-dashboard/orders/', views.admin_orders, name='admin_orders'),
    
    # 教师相关 URL
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)