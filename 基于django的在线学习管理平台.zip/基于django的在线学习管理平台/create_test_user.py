"""
快速创建测试用户脚本（自动模式）
创建学生和管理员两个账号
"""
import os
import sys
import django

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'myproject'))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'myproject.settings')
django.setup()

from django.contrib.auth.models import User
from myapp.models import UserProfile

print("=" * 60)
print("=== 创建测试账号 ===")
print("=" * 60)

# 创建学生账号
student_username = 'student'
student_password = '123456'

User.objects.filter(username=student_username).delete()
student = User.objects.create_user(username=student_username, password=student_password)
student.save()
profile, _ = UserProfile.objects.get_or_create(user=student)
profile.role = UserProfile.ROLE_STUDENT
profile.save()

print(f"\n学生账号:")
print(f"  用户名：{student_username}")
print(f"  密码：{student_password}")
print(f"  角色：学生")

# 创建管理员账号
admin_username = 'admin'
admin_password = 'admin123'

User.objects.filter(username=admin_username).delete()
admin_user = User.objects.create_user(username=admin_username, password=admin_password, is_staff=True, is_superuser=True)
admin_user.save()
profile, _ = UserProfile.objects.get_or_create(user=admin_user)
profile.role = UserProfile.ROLE_ADMIN
profile.save()

print(f"\n管理员账号:")
print(f"  用户名：{admin_username}")
print(f"  密码：{admin_password}")
print(f"  角色：管理员")

print("\n" + "=" * 60)
print("OK! 账号创建成功！")
print("=" * 60)
print("\n登录方式：")
print("  - 学生登录：访问 http://127.0.0.1:8000/login/")
print("  - 管理员登录：访问 http://127.0.0.1:8000/admin/login/")
print("=" * 60)
