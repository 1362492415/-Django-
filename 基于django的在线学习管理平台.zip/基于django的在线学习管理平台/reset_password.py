"""
重置指定用户的密码为明文格式
"""
import os
import sys
import django

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'myproject'))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'myproject.settings')
django.setup()

from django.contrib.auth.models import User
from myapp.models import UserProfile

# 指定要重置的用户名和新密码
username = input("输入要重置的用户名：").strip()
new_password = input("输入新密码：").strip()

if not username or not new_password:
    print("用户名和密码不能为空！")
    sys.exit(1)

# 查找用户
try:
    user = User.objects.get(username=username)
    
    # 直接设置明文密码
    user.password = f'plain${new_password}'
    user.save()
    
    # 确保有 profile
    profile, created = UserProfile.objects.get_or_create(user=user)
    if created:
        profile.role = UserProfile.ROLE_STUDENT
        profile.save()
    
    print(f"\nOK! 用户 {username} 的密码已重置为：{new_password}")
    print(f"密码存储格式：plain${new_password}")
    
except User.DoesNotExist:
    print(f"用户 {username} 不存在！")
